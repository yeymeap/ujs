﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        private Button[] b = new Button[10];
        private Random rnd = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void Ujrainditas()
        {
            for (int i=0; i<10; i++)
            {
                b[i].Location = new Point(b[i].Location.X, 10);
                b[i].BackColor = Color.White;
                b[i].Text = "Kattints ide!";
            }
        }

        private void Kattintas(object sender, EventArgs e)
        {
            if (OsszesFentVan())
            {
                timer1.Enabled = true;
            }
            else
            {
                Button btn = (Button)sender;
                btn.BackColor = Color.Red;
                int hanyadik = (btn.Location.X - 10) / 60;
                btn.Text = hanyadik.ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                b[i] = new Button();
                b[i].Size = new Size(50, 50);
                b[i].Location = new Point(i*60+10, 10);
                b[i].Text = "Kattints ide!";
                b[i].BackColor = Color.White;
                b[i].Click += new EventHandler(Kattintas);
                this.Controls.Add(b[i]);
            }
        }

        private bool OsszesFentVan()
        {
            bool fentVannak = true;
            for (int i = 0; i < 10; i++)
            {
                if (b[i].Location.Y > 10)
                {
                    fentVannak = false;
                }
            }
            return fentVannak;
        }

        private bool OsszesLentVan()
        {
            bool lentVannak = true;
            for (int i=0; i<10; i++)
            {
                int x = b[i].Location.X;
                int y = b[i].Location.Y;
                if (y < this.ClientSize.Height - b[i].Height - 10)
                {
                    lentVannak = false;
                }
            }
            return lentVannak;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int r = rnd.Next(10);  // 0..9
            int x = b[r].Location.X;
            int y = b[r].Location.Y;
            if (y < this.ClientSize.Height - b[r].Height - 10)
            {
                b[r].Location = new Point(x, y + 10);
            }
            if (OsszesLentVan())
            {
                timer1.Enabled = false;
                Ujrainditas();
            }
        }
    }
}
