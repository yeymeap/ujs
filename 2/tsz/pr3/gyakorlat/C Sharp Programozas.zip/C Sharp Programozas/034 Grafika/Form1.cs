﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace _034_Grafika
{
    public partial class Form1 : Form
    {

        // korvanal szinek
        private Pen kek = new Pen(Color.Blue);
        private Pen fekete = new Pen(Color.Black);
        // kitoltes szinek
        private SolidBrush sarga = new SolidBrush(Color.Yellow);
        private SolidBrush piros = new SolidBrush(Color.Red);
        // pontok
        private Point p1 = new Point(30, 50);
        private Point p2 = new Point(170, 50);
        private Point p3 = new Point(30, 100);
        // alakzatok
        private Rectangle teglalap = new Rectangle(200, 30, 150, 50);
        private Rectangle ellipszis = new Rectangle(200, 100, 150, 50);
        private Rectangle kor = new Rectangle(0, 0, 20, 20);


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
            this.DoubleBuffered = true;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;            
            // Rajzolas...                     
            g.DrawLine(fekete, p1, p2);
            g.DrawImage(Properties.Resources.csillag, p3);
            g.FillRectangle(sarga, teglalap);
            g.DrawRectangle(kek, teglalap);
            g.FillEllipse(sarga, ellipszis);
            g.DrawEllipse(kek, ellipszis);
            g.FillEllipse(piros, kor);
            g.DrawEllipse(fekete, kor);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // kor objektom modositasa
            kor.X += 4;
            kor.Y += 2;
            kor.Width++;
            kor.Height++;
            // ujrarajzolas kikenyszeritese
            this.Invalidate();
        }
    }
}
