﻿using System;

namespace _020_OOP_Metodus_tulterheles
{
    public class Szemely
    {
        public string Nev { get; }
        public int SzuletesiEv { get; }

        public Szemely(string aNev, int aSzuletesiEv)
        {
            Nev = aNev;
            SzuletesiEv = aSzuletesiEv;
        }

        public int Eletkor()
        {
            return DateTime.Now.Year - SzuletesiEv;
        }

        public int Eletkor(int evszam)
        {
            return evszam - SzuletesiEv;
        }

        public override string ToString()
        {
            return Nev + " (" + SzuletesiEv + ")";
        }
    }
}

