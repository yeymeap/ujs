﻿using System;
using System.Windows.Forms;

namespace _020_OOP_Metodus_tulterheles
{
    public partial class Form1 : Form
    {

        private Diak d1, d2;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.AppendText(d1.Nev + " most " + d1.Eletkor() + " éves.\n");
            textBox2.AppendText(d2.Nev + " most " + d2.Eletkor() + " éves.\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int ev = Convert.ToInt32(textBox1.Text);
            textBox2.AppendText(d1.Nev + " életkora " + ev + "-ben: " + d1.Eletkor(ev) + "\n");
            textBox2.AppendText(d2.Nev + " életkora " + ev + "-ben: " + d2.Eletkor(ev) + "\n");
        }

        private void JegyekKiirasa(Diak diak)
        {            
            int[] jegyek = diak.OsszesJegy();           
            if (jegyek.Length==0)
            {
                textBox2.AppendText(diak.Nev + " nem kapott eddig még egy jegyet sem.\n");
            } else
            {
                textBox2.AppendText(diak.Nev + " jegyei: ");
                foreach (int j in jegyek)
                {
                    textBox2.AppendText(j + ", ");
                }
                textBox2.AppendText("\n");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            JegyekKiirasa(d1);
            JegyekKiirasa(d2);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            d1 = new Diak("Feri", 2003, new int[] { 1, 2, 2, 1, 2 });
            d2 = new Diak("Timi", 2002);
        }
    }
}
