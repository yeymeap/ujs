﻿using System;
using System.IO;
using System.Windows.Forms;

namespace _033_Adatfolyamok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const string fileNev1 = "../../TextFile1.txt";  // allomany, amelybol olvasni fogunk
        const string fileNev2 = "../../TextFile2.txt";   // allomany, amelybe irni fogunk
        const int BufferMerete = 1024;                   // buffer merete bajtokban

        private void button1_Click(object sender, EventArgs e)
        {
            if (!File.Exists(fileNev1))
            {
                MessageBox.Show(fileNev1 + " állomany nem található!", "Hiba!",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                // Stream objektumok hasznalata 
                Stream inStream = File.OpenRead(fileNev1);
                Stream outStream = File.OpenWrite(fileNev2);
                // olvasashoz/irashoz hasznalt buffer letrehozasa
                byte[] buffer = new Byte[BufferMerete];
                // olvas/iras
                int numBytes;
                while ((numBytes = inStream.Read(buffer, 0, BufferMerete)) > 0)
                {
                    outStream.Write(buffer, 0, numBytes);
                }
                // adatfolyamok bezarasa
                inStream.Close();
                outStream.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!File.Exists(fileNev1))
            {
                MessageBox.Show(fileNev1 + " állomany nem található!", "Hiba!",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                // Stream es BufferedStrean objektumok hasznalata 
                Stream inStream = File.OpenRead(fileNev1);
                Stream outStream = File.OpenWrite(fileNev2);
                BufferedStream inBuffStream = new BufferedStream(inStream);
                BufferedStream outBuffStream = new BufferedStream(outStream);
                // olvasashoz/irashoz hasznalt buffer letrehozasa 
                byte[] buffer = new Byte[BufferMerete];
                // olvas/iras
                int numBytes;
                while ((numBytes = inBuffStream.Read(buffer, 0, BufferMerete)) > 0)
                {
                    outBuffStream.Write(buffer, 0, numBytes);
                }
                // adatfolyamok bezarasa
                inBuffStream.Close();
                outBuffStream.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!File.Exists(fileNev1))
            {
                MessageBox.Show(fileNev1 + " állomany nem található!", "Hiba!",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                // FileStream objektumok hasznalata 
                FileStream inStream = new FileStream(fileNev1, FileMode.Open, FileAccess.Read);
                FileStream outStream = new FileStream(fileNev2, FileMode.Create, FileAccess.Write);
                // olvasashoz/irashoz hasznalt buffer letrehozasa 
                byte[] buffer = new Byte[BufferMerete];
                // olvas/iras
                int numBytes;
                while ((numBytes = inStream.Read(buffer, 0, BufferMerete)) > 0)
                {
                    outStream.Write(buffer, 0, numBytes);
                }
                // adatfolyamok bezarasa
                inStream.Close();
                outStream.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {            
            if (!File.Exists(fileNev1))
            {
                MessageBox.Show(fileNev1 + " állomany nem található!", "Hiba!",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                // StreamReader, StreamWriter objektumok hasznalata (TXT allomanyoknal)
                StreamReader sr = File.OpenText(fileNev1);
                StreamWriter sw = File.CreateText(fileNev2);
                // olvasas/iras soronkent
                String sor;                
                while ((sor = sr.ReadLine()) != null)
                {
                    sw.WriteLine(sor);
                }
                // adatfolyamok bezarasa
                sr.Close();
                sw.Close();
            }
        }
    }
}
