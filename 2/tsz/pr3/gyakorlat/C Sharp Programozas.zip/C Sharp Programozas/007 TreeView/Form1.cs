﻿using System;
using System.Windows.Forms;

namespace _007_TreeView
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Form betöltésekor (program indulásakor)...
        private void Form1_Load(object sender, EventArgs e)
        {
            // kezdeti tulajdonsagok beallitasa
            treeView1.HideSelection = false;
            button1.Enabled = false;
            // fa letrehozasa
            TreeNode n1 = treeView1.Nodes.Add("Színek");
            n1.Nodes.Add("Piros");
            n1.Nodes.Add("Zöld");
            TreeNode n2 = n1.Nodes.Add("Kék");
            n2.Nodes.Add("Sötétkék");
            n2.Nodes.Add("Világoskék");
        }

        // Amikor a textBox1-ben a szöveg megváltozik...
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "")
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }

        // Hozzáadás gomb...
        private void button1_Click(object sender, EventArgs e)
        {
            TreeNode kivalasztott = treeView1.SelectedNode;
            if (kivalasztott != null && !checkBox1.Checked)
            {
                kivalasztott.Nodes.Add(textBox1.Text);
            } else
            {
                treeView1.Nodes.Add(textBox1.Text);
            }
        }

        // Törlés gomb...
        private void button2_Click(object sender, EventArgs e)
        {
            TreeNode kivalasztott = treeView1.SelectedNode;
            if (kivalasztott != null)
            {
                kivalasztott.Remove();
            } else
            {
                MessageBox.Show("Nincs mit törölni, előbb jelölj ki valamit!",
                    "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Összes szétnyitása gomb...
        private void button3_Click(object sender, EventArgs e)
        {
            treeView1.ExpandAll();
        }

        // Összes bezárása gomb...
        private void button4_Click(object sender, EventArgs e)
        {
            treeView1.CollapseAll();
        }
    }
}
