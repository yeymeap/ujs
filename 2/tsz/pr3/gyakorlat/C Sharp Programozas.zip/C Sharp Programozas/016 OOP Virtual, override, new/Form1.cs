﻿using System;
using System.Windows.Forms;

namespace _016_OOP_Virtual__override__new
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            B x = new B();
            textBox1.AppendText(x.StatikusKotes() + "\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            B x = new B();
            textBox1.AppendText(x.DinamikusKotes() + "\n");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            A x = new B();
            textBox1.AppendText(x.StatikusKotes() + "\n");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            A x = new B();
            textBox1.AppendText((x as B).StatikusKotes() + "\n");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            A x = new B();
            textBox1.AppendText(x.DinamikusKotes() + "\n");
        }
    }
}
