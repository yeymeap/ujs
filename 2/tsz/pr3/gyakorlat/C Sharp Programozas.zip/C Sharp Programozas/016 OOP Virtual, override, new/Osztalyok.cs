﻿namespace _016_OOP_Virtual__override__new
{
    public class A
    {
        public string StatikusKotes()
        {
            return "A osztály StatikusKotes() metódusa.";
        }

        public virtual string DinamikusKotes()
        {
            return "A osztály DinamikusKotes() metódusa.";
        }

    }

    public class B : A
    {
        public new string StatikusKotes()
        {
            return "B osztály StatikusKotes() metódusa.";
        }

        public override string DinamikusKotes()
        {
            return "B osztály DinamikusKotes() metódusa.";
        }
    }   

}


