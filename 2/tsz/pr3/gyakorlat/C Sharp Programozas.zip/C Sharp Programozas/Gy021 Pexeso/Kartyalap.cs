﻿using System.Drawing;
using System.Windows.Forms;

namespace _Gy021_Pexeso
{
    class Kartyalap : Button
    {
        public const int SZELESSEG = 140;

        private bool felforditva = false;
        private Bitmap kep;

        public Kartyalap(Bitmap kep)
        {
            this.kep = kep;            
            this.Size = new Size(SZELESSEG, SZELESSEG);
            this.Text = "";
            this.Image = Properties.Resources.hatter;
        }

        public void Fordit()
        {
            felforditva = !felforditva;
            if (felforditva)
            {
                this.Image = this.kep;
            } else
            {
                this.Image = Properties.Resources.hatter;
            }
        }

        public void Kepcsere(Kartyalap k)
        {
            Bitmap tmp = this.kep;
            this.kep = k.kep;
            k.kep = tmp;
        }

        public bool Egyforma(Kartyalap k)
        {
            return this.kep == k.kep;
        }

    }
}
