﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace _Gy021_Pexeso
{
    public partial class Form1 : Form
    {
        private Random randgen = new Random();
        private Bitmap[] kepek = { Properties.Resources.kep0,
                                   Properties.Resources.kep1,
                                   Properties.Resources.kep2,
                                   Properties.Resources.kep3,
                                   Properties.Resources.kep4,
                                   Properties.Resources.kep5,
                                   Properties.Resources.kep6,
                                   Properties.Resources.kep7 };
        private Kartyalap[] lapok = new Kartyalap[16];
        private Kartyalap lap1 = null, lap2 = null;
        private int talaltPar = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // kartyak letrehozasa
            int k = 0;
            for (int sor = 0; sor < 4; sor++)
            {
                for (int oszlop = 0; oszlop < 4; oszlop++)
                {
                    lapok[k] = new Kartyalap(kepek[k / 2]);
                    lapok[k].Location = new Point(oszlop * Kartyalap.SZELESSEG, 
                                                  sor * Kartyalap.SZELESSEG);
            lapok[k].Click += new EventHandler(Kattintas);
            Controls.Add(lapok[k]);
            k++;
        }
    }
    // Ablak meretenek beallitasa
    ClientSize = new Size(4 * Kartyalap.SZELESSEG, 4 * Kartyalap.SZELESSEG);
    // kartyakon a kepek megkeverese
    LapokKeverese();
}

private void LapokKeverese()
{
    for (int i = 0; i < 16; i++)
    {
        // a lap lathatova tetele
        lapok[i].Visible = true;
        // a lapon a kep kicserelese egy masik veletlenszeruen kivalasztott lap kevepel
        int j = randgen.Next(i, 16);
        lapok[i].Kepcsere(lapok[j]);
    }
    // megtalalt lapok szama
    talaltPar = 0;
}

private void Kattintas(Object sender, EventArgs e)
{
    Kartyalap k = (Kartyalap)sender;
    if (lap1 == null)
    {
        lap1 = k;
        lap1.Fordit();
    }
    else if (lap1 != k && lap2 == null)
    {
        lap2 = k;
        lap2.Fordit();
        timer1.Enabled = true;
    }
}

private void timer1_Tick(object sender, EventArgs e)
{
    timer1.Enabled = false;
    lap1.Fordit();
    lap2.Fordit();
    if (lap1.Egyforma(lap2))
    {
        lap1.Visible = false;
        lap2.Visible = false;
        talaltPar++;
        // vege a jateknak?
        if (talaltPar == 8)
        {
            MessageBox.Show("Sikerült megtalálnod az összes párt!", "Gratulálunk!");
            LapokKeverese();
        }
    }
    lap1 = null;
    lap2 = null;
}
    }
}
