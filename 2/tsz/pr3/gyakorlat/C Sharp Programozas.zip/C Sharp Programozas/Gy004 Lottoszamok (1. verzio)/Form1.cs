﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gy004_Lottoszamok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] a = new int[5];
            Random randgen = new Random();
            // szamok generalasa
            for (int i=0; i<5; i++)
            {
                int r;
                bool van;
                do
                {
                    r = randgen.Next(1, 91);
                    van = false;
                    foreach (int x in a)
                    {
                        if (x == r)
                        {
                            van = true;
                        }
                    }
                } while (van);
                a[i] = r;                
            }
            // szamok rendezese (egyszeru cseres rendezes)
            for (int i=0; i<4; i++)
            {
                for (int j=i+1; j<5; j++)
                {
                    if (a[i]>a[j])
                    {
                        int tmp = a[i];
                        a[i] = a[j];
                        a[j] = tmp;
                    }
                }
            }
            // szamok kiirasa
            label1.Text = "Számok: ";
            foreach (int x in a)
            {
                label1.Text = label1.Text + x + ", ";
            }
        }
    }
}
