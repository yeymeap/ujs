﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _005_Fuggvenyek
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private int osszegSzamitas(int a, int b, int c)
        {
            int sum = a + b + c;
            a = a * 2;
            b = b * 2;
            c = c * 2;
            return sum;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sz1 = Convert.ToInt32(textBox1.Text);
            int sz2 = Convert.ToInt32(textBox2.Text);
            int sz3 = Convert.ToInt32(textBox3.Text);
            textBox4.AppendText("Függvényhívás előtt: " +
                "sz1=" + sz1 + ", sz2=" + sz2 + ", sz3=" + sz3 + "\n");
            int osszeg = osszegSzamitas(sz1, sz2, sz3);
            textBox4.AppendText("Függvényhívás után: " +
                "sz1=" + sz1 + ", sz2=" + sz2 + ", sz3=" + sz3 + "\n");
            label1.Text = "Összeg: " + osszeg;
        }

        private void duplazas(ref int a, ref int b, ref int c)
        {
            a = a * 2;
            b = b * 2;
            c = c * 2;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sz1 = Convert.ToInt32(textBox1.Text);
            int sz2 = Convert.ToInt32(textBox2.Text);
            int sz3 = Convert.ToInt32(textBox3.Text);
            textBox4.AppendText("Függvényhívás előtt: " +
                "sz1=" + sz1 + ", sz2=" + sz2 + ", sz3=" + sz3 + "\n");
            duplazas(ref sz1, ref sz2, ref sz3);
            textBox4.AppendText("Függvényhívás után: " +
                "sz1=" + sz1 + ", sz2=" + sz2 + ", sz3=" + sz3 + "\n");
            textBox1.Text = sz1.ToString();
            textBox2.Text = sz2.ToString();
            textBox3.Text = sz3.ToString();
        }

        private void veletlenSzamok(out int a, out int b, out int c)
        {
            Random gen = new Random();
            a = gen.Next(100);         // 0..99
            b = gen.Next(1, 100);      // 1..99
            c = gen.Next(-10, 11);     // -10..10
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int sz1, sz2, sz3;
            textBox4.AppendText("Függvényhívás előtt: " +
                "sz1, sz2, sz3-nak nincs értéke!\n");
            veletlenSzamok(out sz1, out sz2, out sz3);
            textBox4.AppendText("Függvényhívás után: " +
                "sz1=" + sz1 + ", sz2=" + sz2 + ", sz3=" + sz3 + "\n");
            textBox1.Text = sz1.ToString();
            textBox2.Text = sz2.ToString();
            textBox3.Text = sz3.ToString();
        }

    }
}
