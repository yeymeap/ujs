﻿using System;
using System.Windows.Forms;

namespace _003_Nevterek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double elso = Convert.ToDouble(textBox1.Text);
            double masodik = Convert.ToDouble(textBox2.Text);
            double osszeg = elso + masodik;
            label3.Text = String.Format("{0} + {1} = {2}", elso, masodik, osszeg);
        }
    }
}
