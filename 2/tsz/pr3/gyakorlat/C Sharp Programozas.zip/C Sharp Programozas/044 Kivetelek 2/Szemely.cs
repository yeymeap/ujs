﻿namespace _044_Kivetelek_2
{
    public class Szemely
    {
        private string nev;
        private long szulSzam;

        public Szemely(string nev, long szulSzam)
        {
            this.nev = nev;
            this.szulSzam = szulSzam;
        }

        public override string ToString()
        {
            return nev + " (" + szulSzam + ")";
        }

    }
}
