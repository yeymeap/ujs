﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _044_Kivetelek_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nev = textBox1.Text;
            long szulSzam = 0;
            try
            {
                szulSzam = Convert.ToInt64(textBox2.Text);
            }
            catch (FormatException)
            {
                if (textBox2.Text.Length == 0)
                {
                    MessageBox.Show("Nincs megadva a születési szám!", "HIBA",
                     MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("A születési szám csak számjegyeket tartalmazhat!", "HIBA",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return;
            }
            Szemely sz = new Szemely(nev, szulSzam);
            textBox3.AppendText(sz + "\r\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nev = textBox1.Text;
            long szulSzam = 0;
            try
            {
                szulSzam = Convert.ToInt64(textBox2.Text);
            }
            catch (FormatException) when (textBox2.Text.Length == 0)
            {
                MessageBox.Show("Nincs megadva a születési szám!", "HIBA",
                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            catch (FormatException)
            {
                MessageBox.Show("A születési szám csak számjegyeket tartalmazhat!", "HIBA",
                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Szemely sz = new Szemely(nev, szulSzam);
            textBox3.AppendText(sz + "\r\n");
        }
    }
}
