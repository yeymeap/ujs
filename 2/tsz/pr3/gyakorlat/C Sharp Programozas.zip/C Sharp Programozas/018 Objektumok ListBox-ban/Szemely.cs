﻿using System;

namespace _018_Objektumok_ListBox__ban
{
    public class Szemely
    {
        public string Nev { get; }
        public int SzuletesiEv { get; }

        public Szemely(string aNev, int aSzuletesiEv)
        {
            Nev = aNev;
            SzuletesiEv = aSzuletesiEv;
        }

        public int Eletkor()
        {
            return DateTime.Now.Year - SzuletesiEv;
        }

        public override string ToString()
        {
            return Nev + " (" + SzuletesiEv + ")";
        }
    }
}

