﻿using System;
using System.Windows.Forms;

namespace _018_Objektumok_ListBox__ban
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label4.Enabled = false;
            textBox3.Enabled = false;
            label5.Enabled = false;
            textBox4.Enabled = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label4.Enabled = true;
            textBox3.Enabled = true;
            label5.Enabled = false;
            textBox4.Enabled = false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            label4.Enabled = false;
            textBox3.Enabled = false;
            label5.Enabled = true;
            textBox4.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Szemely x;
            if (radioButton1.Checked)
            {   // Szemely letrehozasa
                x = new Szemely(textBox1.Text, Convert.ToInt32(textBox2.Text));
            } else if (radioButton2.Checked)
            {   // Diak letrehozasa
                string[] jegyekString = textBox3.Text.Split(' ');
                int[] jegyekInt = new int[jegyekString.Length];
                for (int i = 0; i < jegyekString.Length; i++)
                {
                    jegyekInt[i] = Convert.ToInt32(jegyekString[i]);
                }
                x = new Diak(textBox1.Text, Convert.ToInt32(textBox2.Text),
                             jegyekInt);
            } else
            {   // Munkas letrehozasa
                x = new Munkas(textBox1.Text, Convert.ToInt32(textBox2.Text), 
                               Convert.ToDouble(textBox4.Text));
            }
            // Objektum hozzaadasa a ListBox elemeihez
            listBox1.Items.Add(x);
            // TextBox-okban levo szoveget torlese
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox5.Clear();
            Szemely x = (Szemely)listBox1.SelectedItem;
            if (x is Diak)
            {
                textBox5.AppendText("Diak neve: " + x.Nev + "\n");
                textBox5.AppendText("Születési éve: " + x.SzuletesiEv + "\n");
                textBox5.AppendText("Jegyei: ");
                foreach (int j in (x as Diak).OsszesJegy())
                {
                    textBox5.AppendText(j + ", ");
                }
                textBox5.AppendText("\n");
            } else if (x is Munkas)
            {
                textBox5.AppendText("Munkas neve: " + x.Nev + "\n");
                textBox5.AppendText("Születési éve: " + x.SzuletesiEv + "\n");
                textBox5.AppendText("Fizetése: " + (x as Munkas).GetFizetes() + "\n");
            } else
            {
                textBox5.AppendText("Szemely neve: " + x.Nev + "\n");
                textBox5.AppendText("Születési éve: " + x.SzuletesiEv + "\n");
            }
        }
    }
}
