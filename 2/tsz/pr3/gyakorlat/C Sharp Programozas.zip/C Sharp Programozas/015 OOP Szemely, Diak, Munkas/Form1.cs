﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _015_OOP_Szemely__Diak__Munkas
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private Szemely sz1, sz2;
        private Diak d1, d2;
        private Munkas m1, m2;

        private void button1_Click(object sender, EventArgs e)            
        {
            textBox1.Clear();
            textBox1.AppendText("----- Objektumok létrehozása 1 -----\n");
            sz1 = new Szemely("Peti", 1996);
            sz2 = new Szemely("Éva", 1999);
            d1 = new Diak("Feri", 2003, new int[] { 1, 2, 2, 1, 2 });
            d2 = new Diak("Timi", 2002, new int[] { 1, 1, 3, 1});
            m1 = new Munkas("Zoli", 1995, 590);
            m2 = new Munkas("Tomi", 1997, 560);            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("----- Életkorok kiírása 1 -----\n");
            textBox1.AppendText("Szemely: " + sz1.Nev + " most " + sz1.Eletkor() + " éves.\n");
            textBox1.AppendText("Szemely: " + sz2.Nev + " most " + sz2.Eletkor() + " éves.\n");
            textBox1.AppendText("Diak: " + d1.Nev + " most " + d1.Eletkor() + " éves.\n");
            textBox1.AppendText("Diak: " + d2.Nev + " most " + d2.Eletkor() + " éves.\n");
            textBox1.AppendText("Munkas: " + m1.Nev + " most " + m1.Eletkor() + " éves.\n");
            textBox1.AppendText("Munkas: " + m2.Nev + " most " + m2.Eletkor() + " éves.\n");
        }

        private Szemely[] tomb = new Szemely[6];

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.AppendText("----- Objektumok létrehozása 2 -----\n");
            tomb[0] = new Szemely("Peti", 1996);
            tomb[1] = new Szemely("Éva", 1999);
            tomb[2] = new Diak("Feri", 2003, new int[] { 1, 2, 2, 1, 2 });
            tomb[3] = new Diak("Timi", 2002, new int[] { 1, 1, 3, 1 });
            tomb[4] = new Munkas("Zoli", 1995, 590);
            tomb[5] = new Munkas("Tomi", 1997, 560);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("----- Életkorok kiírása 2 -----\n");
            foreach (Szemely x in tomb)
            {
                textBox1.AppendText(x.GetType().Name + ": " + x.Nev + " most " +
                                    x.Eletkor() + " éves.\n");                
            }
        }

    }
}
