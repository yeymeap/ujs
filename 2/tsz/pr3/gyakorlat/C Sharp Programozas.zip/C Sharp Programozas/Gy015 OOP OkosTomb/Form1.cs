﻿using System;
using System.Windows.Forms;

namespace Gy015_OOP_OkosTomb
{
    public partial class Form1 : Form
    {
        private OkosTomb a;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            a = new OkosTomb(8);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            a.Generalas();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            a.Generalas(100, 999);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            a.Kiiras(textBox1);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int[] x = a.GetOkosTomb();
            foreach (int elem in x)
            {
                textBox1.AppendText(elem + ", ");
            }
            textBox1.AppendText("\n");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int min = a.Min();
            textBox1.AppendText("Minimum: " + min + "\n");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int max = a.Max();
            textBox1.AppendText("Maximum: " + max + "\n");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int ossz = a.Osszeg();
            textBox1.AppendText("Osszeg: " + ossz + "\n");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            double atl = a.Atlag();
            textBox1.AppendText("Atlag: " + atl + "\n");
        }
    }
}
