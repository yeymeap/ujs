﻿using System;
using System.Windows.Forms;

namespace Gy015_OOP_OkosTomb
{
    class OkosTomb
    {
        private int[] _tomb;

        public OkosTomb(int tombMerete)
        {
            _tomb = new int[tombMerete];
            for (int i=0; i<tombMerete; i++)
            {
                _tomb[i] = 0;
            }
        }

        public int[] GetOkosTomb()
        {
            return _tomb;
        }

        public void Kiiras(TextBox tbox)
        {
            tbox.AppendText("Az okos tömb elemei: ");
            foreach(int x in _tomb)
            {
                tbox.AppendText(x + ", ");
            }
            tbox.AppendText("\n");
        }

        public void Generalas()
        {
            Random randGen = new Random();
            for (int i = 0; i < _tomb.Length; i++)
            {
                _tomb[i] = randGen.Next(101);
            }
        }

        public void Generalas(int min, int max)
        {
            Random randGen = new Random();
            for (int i = 0; i < _tomb.Length; i++)
            {
                _tomb[i] = randGen.Next(min,max+1);
            }
        }

        public int Min()
        {
            int min = _tomb[0];
            foreach (int x in _tomb)
            {
                if (x < min)
                {
                    min = x;
                }
            }
            return min;
        }

        public int Max()
        {
            int max = _tomb[0];
            foreach (int x in _tomb)
            {
                if (x > max)
                {
                    max = x;
                }
            }
            return max;
        }

        public int Osszeg()
        {
            int ossz = 0;
            foreach (int x in _tomb)
            {
                ossz += x;
            }
            return ossz;
        }

        public double Atlag()
        {
            return (double)Osszeg() / _tomb.Length;
        }

    }
}
