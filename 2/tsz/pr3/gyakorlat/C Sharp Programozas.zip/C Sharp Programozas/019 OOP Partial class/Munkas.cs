﻿namespace _019_OOP_Partial_class
{
    public partial class Munkas : Szemely
    {

        private double _fizetes;

        public Munkas(string aNev, int aSzuletesiEv, double aFizetes) : base(aNev, aSzuletesiEv)
        {
            _fizetes = aFizetes;
        }

        public double GetFizetes()
        {
            return _fizetes;
        }

    }
}

