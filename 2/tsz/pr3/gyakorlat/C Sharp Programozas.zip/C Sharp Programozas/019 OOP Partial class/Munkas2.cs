﻿using System;

namespace _019_OOP_Partial_class
{
    public partial class Munkas
    {

        public void FizetesEmeles(int szazalek)
        {
            _fizetes = _fizetes + _fizetes * (szazalek / 100.0);
            _fizetes = Math.Round(_fizetes, 2);
        }

        public void FizetesCsokkentes(int szazalek)
        {
            _fizetes = _fizetes - _fizetes * (szazalek / 100.0);
            _fizetes = Math.Round(_fizetes, 2);
        }

    }
}

