﻿using System;
using System.Windows.Forms;

namespace _019_OOP_Partial_class
{
    public partial class Form1 : Form
    {
        private Munkas m1, m2;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            m1 = new Munkas("Zoli", 1995, 590);
            m2 = new Munkas("Tomi", 1997, 560);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("----- Adatok kiírása -----\n");
            textBox1.AppendText(m1.Nev + " születési éve: " + m1.SzuletesiEv +
                ", életkora: " + m1.Eletkor() + ", fizetése: " + m1.GetFizetes() + "\n");
            textBox1.AppendText(m2.Nev + " születési éve: " + m2.SzuletesiEv +
                ", életkora: " + m2.Eletkor() + ", fizetése: " + m2.GetFizetes() + "\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("----- 10% fizetésemelés -----\n");
            m1.FizetesEmeles(10);
            m2.FizetesEmeles(10);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.AppendText("----- 10% fizetéscsökkentés -----\n");
            m1.FizetesCsokkentes(10);
            m2.FizetesCsokkentes(10);
        }

    }
}
