﻿using System;
using System.IO;
using System.Windows.Forms;

namespace _045_Kivetelek_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                StreamReader sr = File.OpenText("../../akarmi.txt");
                try
                {
                    String sor;
                    while ((sor = sr.ReadLine()) != null)
                    {
                        textBox1.AppendText(sor + "\r\n");
                    }
                }
                catch (IOException)
                {
                    MessageBox.Show("Hiba az állomány olvasásánál!", "HIBA",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    sr.Close();
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Az állomány nem található!", "HIBA",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);                
            }

        }
    }
}
