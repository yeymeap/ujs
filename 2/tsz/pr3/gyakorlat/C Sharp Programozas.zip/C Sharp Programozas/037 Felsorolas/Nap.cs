﻿namespace _037_Felsorolas
{
    public enum Nap
    {
        Hétfő = 1,
        Kedd = 2,
        Szerda = 3,
        Csütörtök = 4,
        Péntek = 5,
        Szombat = 6,
        Vasárnap = 7,
        Ismeretlen = -1
    }
}
