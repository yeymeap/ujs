﻿using System;
using System.Windows.Forms;

namespace _037_Felsorolas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Nap n = Nap.Hétfő;
            switch (comboBox1.Text)
            {
                case "Hétfő":
                    n = Nap.Hétfő;
                    break;
                case "Kedd":
                    n = Nap.Kedd;
                    break;
                case "Szerda":
                    n = Nap.Szerda;
                    break;
                case "Csütörtök":
                    n = Nap.Csütörtök;
                    break;
                case "Péntek":
                    n = Nap.Péntek;
                    break;
                case "Szombat":
                    n = Nap.Szombat;
                    break;
                case "Vasárnap":
                    n = Nap.Vasárnap;
                    break;
            }
            label1.Text = "A kiválasztott nap: " + n + ", a hét " + (int)n + ". napja.";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Dock = DockStyle.Right;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Dock = DockStyle.Bottom;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Dock = DockStyle.None;
        }

    }
}
