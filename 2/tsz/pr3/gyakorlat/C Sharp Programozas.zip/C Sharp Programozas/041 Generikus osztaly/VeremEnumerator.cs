﻿using System.Collections;

namespace _041_Generikus_osztaly
{
    public class VeremEnumerator<T> : IEnumerator
    {
        private T[] tomb;
        private int index;

        public object Current
        {
            get
            {
                return tomb[index];
            }
        }

        public VeremEnumerator(T[] tomb)
        {
            this.tomb = tomb;
            index = tomb.Length;
        }

        public bool MoveNext()
        {
            index--;
            return index >= 0;
        }

        public void Reset()
        {
            index = tomb.Length;
        }
    }
}
