﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace _041_Generikus_osztaly
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Verem<int> v1 = new Verem<int>(10);
            v1.ElemBe(2);
            v1.ElemBe(3);
            v1.ElemBe(5);
            v1.ElemBe(7);
            v1.ElemBe(11);
            v1.ElemBe(13);
            textBox1.Clear();
            foreach (int elem in v1)
            {
                textBox1.AppendText(elem + "\r\n");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Verem<String> v2 = new Verem<String>(10);
            v2.ElemBe("Alma");
            v2.ElemBe("Barack");
            v2.ElemBe("Citrom");
            v2.ElemBe("Dió");
            v2.ElemBe("Egres");
            v2.ElemBe("Földimogyoró");
            v2.ElemBe("Gesztenye");
            textBox1.Clear();
            foreach (String elem in v2)
            {
                textBox1.AppendText(elem + "\r\n");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Verem<Color> v3 = new Verem<Color>(10);
            v3.ElemBe(Color.Red);
            v3.ElemBe(Color.Green);
            v3.ElemBe(Color.Blue);
            v3.ElemBe(Color.Yellow);
            v3.ElemBe(Color.Orange);
            v3.ElemBe(Color.Purple);
            v3.ElemBe(Color.Black);
            textBox1.Clear();
            foreach (Color elem in v3)
            {
                textBox1.AppendText(elem + "\r\n");
            }
        }
    }
}
