﻿using System;
using System.Collections;

namespace _041_Generikus_osztaly
{
    public class Verem<T> : IEnumerable
    {
        private T[] elemek;
        private int n = 0;

        public Verem(int meret)
        {
            elemek = new T[meret];
        }

        public void ElemBe(T s)
        {
            if (n < elemek.Length)
            {
                elemek[n] = s;
                n++;
            }
        }

        public T ElemKi()
        {
            if (n > 0)
            {
                n--;
                return elemek[n];
            }
            return default(T);
        }

        public IEnumerator GetEnumerator()
        {
            T[] tomb = new T[n];
            Array.Copy(elemek, 0, tomb, 0, n);
            return new VeremEnumerator<T>(tomb);
        }
    }
}
