﻿namespace _035_Sielo_pingvin_jatek
{
    public class Csillag : TerepJatekelem
    {
        public Csillag(int x, int y) : base(x, y, Properties.Resources.csillag, 20)
        {
        }
    }
}
