﻿namespace _035_Sielo_pingvin_jatek
{
    public class Pingvin : Jatekelem
    {
        public Pingvin(int x, int y) : base(x, y, Properties.Resources.pingvin, 40)
        {
        }

        public void Mozgat(int x)
        {
            this.x = x;
        }
    }
}
