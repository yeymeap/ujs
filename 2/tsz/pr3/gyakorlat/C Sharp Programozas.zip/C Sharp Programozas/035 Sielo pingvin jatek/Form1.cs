﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace _035_Sielo_pingvin_jatek
{
    public partial class Form1 : Form
    {

        private Pingvin jatekos;
        private TerepJatekelem[] objektumok = new TerepJatekelem[15];
        private int pontszam = 0;
        private Random randgen = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // ablak beallitasa
            this.BackColor = Color.FromArgb(245, 250, 255);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;            
            this.DoubleBuffered = true;
            this.CenterToScreen();
            // egerkurzor elrejtese
            Cursor.Hide();
            // jatekos letrehozasa
            jatekos = new Pingvin(this.ClientSize.Width / 2,
                                  this.ClientSize.Height * 2/3 );
            // objektumok letrehozasa
            for (int i = 0; i < objektumok.Length; i++)
            {
                objektumok[i] = TerepJatekelemGeneralas(-this.ClientSize.Height - 50,
                                                        this.ClientSize.Height + 50);
            }
        }

        private TerepJatekelem TerepJatekelemGeneralas(int yMin, int yMax)
        {
            TerepJatekelem o;
            bool vanUtkozes;
            do
            {
                // letrehozunk egy objektumot
                if (randgen.Next(2) == 0)
                {   // fa
                    o = new Fenyofa(randgen.Next(this.ClientSize.Width),
                                    randgen.Next(yMin, yMax));
                }
                else
                {   // csillag
                    o = new Csillag(randgen.Next(this.ClientSize.Width),
                                    randgen.Next(yMin, yMax));
                }
                // megenzzuk utkozik-e a pingvinnel vagy valamelyik masik objektummal
                vanUtkozes = o.Utkozik(jatekos);
                for (int i = 0; i < objektumok.Length; i++)
                {
                    if (o.Utkozik(objektumok[i]))
                    {
                        vanUtkozes = true;
                    }
                }
            } while (vanUtkozes);
            return o;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            jatekos.Kirajzol(g);
            for (int i = 0; i < objektumok.Length; i++)
            {
                objektumok[i].Kirajzol(g);
            }
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            jatekos.Mozgat(e.X);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(245, 250, 255);
            for (int i=0; i<objektumok.Length; i++)
            {
                objektumok[i].Mozgat();
                if (objektumok[i].getY()>this.ClientSize.Height+50)
                {
                    objektumok[i] = TerepJatekelemGeneralas(-this.ClientSize.Height - 50, -50);
                }
                if (jatekos.Utkozik(objektumok[i]))
                {
                    if (objektumok[i] is Fenyofa)
                    {
                        pontszam -= 100;
                        if (pontszam<0)
                        {
                            pontszam = 0;
                        }
                        this.BackColor = Color.Red;                        
                    } else
                    {
                        pontszam += 10;
                        objektumok[i] = TerepJatekelemGeneralas(-this.ClientSize.Height - 50, -50);                        
                    }
                    label1.Text = "Pontszám: " + pontszam;
                }
            }
            this.Invalidate();
        }

    }
}