﻿using System;
using System.Drawing;

namespace _035_Sielo_pingvin_jatek
{
    public class Jatekelem
    {
        protected int x, y;   // koordinatak (kep kozeppontjahoz viszonyitva)
        protected Image kep;  // kirajzolando kep
        private int sugar;    // kozeppontol szamitott sugar (utkozes vizsgalatahoz)

        public Jatekelem(int x, int y, Image kep, int sugar)
        {
            this.x = x;
            this.y = y;
            this.kep = kep;
            this.sugar = sugar;
        }

        public void Kirajzol(Graphics g)
        {
            g.DrawImage(kep, x - kep.Width / 2, y - kep.Height / 2);
        }
        
        public bool Utkozik(Jatekelem m)
        {
            if (m==null)
            {
                return false;
            }
            double tav = Math.Sqrt(Math.Pow(this.x - m.x, 2) + Math.Pow(this.y - m.y, 2));
            return tav < this.sugar + m.sugar;
        }

    }
}
