﻿using System.Drawing;

namespace _035_Sielo_pingvin_jatek
{
    public class TerepJatekelem : Jatekelem
    {
        public TerepJatekelem(int x, int y, Image kep, int sugar) : base(x, y, kep, sugar)
        {
        }
        
        public void Mozgat()
        {
            y = y + 8;
        }

        public int getY()
        {
            return y;
        }

    }
}
