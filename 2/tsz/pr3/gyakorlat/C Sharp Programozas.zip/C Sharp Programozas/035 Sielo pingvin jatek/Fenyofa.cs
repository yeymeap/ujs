﻿namespace _035_Sielo_pingvin_jatek
{
    public class Fenyofa : TerepJatekelem
    {
        public Fenyofa(int x, int y) : base(x, y, Properties.Resources.fenyofa, 30)
        {
        }
    }
}
