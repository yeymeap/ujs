﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gy007_Gondolt_szám
{
    public partial class Form1 : Form
    {

        private Random randGen = new Random();
        private int gondoltSzam;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            gondoltSzam = randGen.Next(1, 51);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int tippeltSzam = Convert.ToInt32(textBox1.Text);
            if (gondoltSzam>tippeltSzam)
            {
                label3.Text = "Nagyobb számra gondoltam!";
            } else if (gondoltSzam < tippeltSzam)
            {
                label3.Text = "Kisebb számra gondoltam!";
            } else
            {
                label3.Text = "Eltaláltad! Gondoltam új számra!";
                gondoltSzam = randGen.Next(1, 51);
            }
        }

    }
}
