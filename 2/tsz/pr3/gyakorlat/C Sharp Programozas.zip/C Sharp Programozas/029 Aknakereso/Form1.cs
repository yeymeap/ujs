﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace _029_Aknakereso
{
    public partial class Form1 : Form
    {
        private Random randgen = new Random();
        private Hely[,] aknamezo = new Hely[10, 10];
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Form beallitasa
            ClientSize = new Size(420, 440);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            // Hely objektumok letrehozasa es hozzaadasa a Form-hoz
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    aknamezo[i, j] = new Hely(i * 40 + 10, j * 40 + 30);
                    aknamezo[i, j].Click += new EventHandler(BalEgerKattintas);
                    Controls.Add(aknamezo[i, j]);
                }
            }
            // jatek inditasa
            JatekInditasa();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // a jatek ujrainditasa
            JatekInditasa();
        }

        // "Click" esemeny - kattintas bal egergombbal egy adott helyre
        private void BalEgerKattintas(object sender, EventArgs e)
        {
            if (!Hely.vege)
            {
                Hely h = (Hely)sender;
                h.SetFelfedve(true);
                if (h.GetAkna())
                {
                    JatekVege();
                }
                else {
                    if (h.AknakMellette == 0)
                    {
                        // melyik helyre kattintottunk?
                        int x = 0, y = 0;
                        for (int i = 0; i < 10; i++)
                        {
                            for (int j = 0; j < 10; j++)
                            {
                                if (aknamezo[i, j] == h)
                                {
                                    x = i;
                                    y = j;
                                }
                            }
                        }
                        // rekurzivan felfedjuk a kozeli helyeket is
                        RekurzivFelfedes(x, y);
                    }
                    // osszes hely fel van-e fedve, kiveve az aknakat?
                    int drb = 0;
                    for (int i = 0; i < 10; i++)
                    {
                        for (int j = 0; j < 10; j++)
                        {
                            if (!aknamezo[i, j].GetFelfedve())
                            {
                                drb++;
                            }
                        }
                    }
                    if (drb == 10)
                    {
                        JatekVege();
                        MessageBox.Show("Sikerült az összes aknát megtalálnod!", 
                            "Gratulálunk!");
                    }
                }                
            }
        }

        private void RekurzivFelfedes(int x, int y)
        {
            aknamezo[x, y].SetFelfedve(true);
            if (aknamezo[x, y].AknakMellette == 0)
            {
                int[] xd = { -1, 0, +1, -1, +1, -1, 0, +1 };
                int[] yd = { -1, -1, -1, 0, 0, +1, +1, +1 };
                for (int i = 0; i < 8; i++)
                {
                    if (x + xd[i] >= 0 && x + xd[i] < 10 
                        && y + yd[i] >= 0 && y + yd[i] < 10)
                    {
                        if (!aknamezo[x + xd[i], y + yd[i]].GetFelfedve())
                        {
                            RekurzivFelfedes(x + xd[i], y + yd[i]);
                        }
                    }
                }
            }            
        }

        private void JatekInditasa()
        {            
            // helyek alapertelmezett helyzetbe allitasa
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    aknamezo[i, j].Alaphelyzet();
                }
            }
            // 10 drb. akna elrejtese veletlen helyekre
            int n = 0;
            do
            {
                int x = randgen.Next(10);
                int y = randgen.Next(10);
                if (!aknamezo[x, y].GetAkna())
                {
                    aknamezo[x, y].SetAkna(true);
                    n++;
                }
            } while (n < 10);
            // a helyek koruli aknak szamanak hozzarendelese az egyes helyekhez
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    aknamezo[i, j].AknakMellette = AknakAHelyKorul(i, j);
                }
            }
            // a jatek aktivra allitasa
            Hely.vege = false;
        }

        private int AknakAHelyKorul(int x, int y)
        {
            int[] xd = { -1, 0, +1, -1, +1, -1, 0, +1 };
            int[] yd = { -1, -1, -1, 0, 0, +1, +1, +1 };
            int drb = 0;
            for (int i = 0; i < 8; i++)
            {
                if (x + xd[i] >= 0 && x + xd[i] < 10 
                    && y + yd[i] >= 0 && y + yd[i] < 10)
                {
                    if (aknamezo[x + xd[i], y + yd[i]].GetAkna())
                    {
                        drb++;
                    }
                }
            }
            return drb;
        }

        private void JatekVege()
        {
            // a jatek inaktivra allitasa
            Hely.vege = true;
            // az aknak helyeinek es a bejelolt helyeknek a felfedese
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (!aknamezo[i, j].GetFelfedve() 
                        && (aknamezo[i,j].GetAkna() || aknamezo[i,j].GetZaszlo()))
                    {
                        aknamezo[i, j].SetFelfedve(true);
                    }                    
                }
            }
        }
        
    }
}
