﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace _029_Aknakereso
{
    public class Hely : Button
    {       
        private bool zaszlo = false;     // meg van-e jelolve zaszloval
        private bool akna = false;       // van-e ezen a helyen akna
        private bool felfedve = false;   // fel van-e fedve a hely

        public int AknakMellette { set; get; } = 0;   // a hely koruli aknak szama

        public static bool vege = false;         // vege-e a jateknank

        // konstruktor
        public Hely(int x, int y)
        {           
            this.Size = new Size(40, 40);
            this.Location = new Point(x, y);
            this.SetStyle(ControlStyles.Selectable, false);
            this.Alaphelyzet();
            this.MouseDown += new MouseEventHandler(JelolesJobbEgerkattintassal);
        }

        // a hely beallitasa alaphelyzetbe
        public void Alaphelyzet()
        {
            this.Text = "";
            this.SetZaszlo(false);
            this.SetAkna(false);
            this.SetFelfedve(false);            
            this.AknakMellette = 0;
        }

        // "MouseDown" esemenyhez hozzarendelt fuggveny 
        // - a hely megjelolese zaszloval / jeloles visszavonasa
        private void JelolesJobbEgerkattintassal(Object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && !Hely.vege && !this.felfedve)
            {
                this.SetZaszlo(!this.zaszlo);
            }
        }

        // akna beallitasa igaz/hamis-ra
        public void SetAkna(bool x)
        {
            this.akna = x;
        }

        // van-e akna a helyen
        public bool GetAkna()
        {
            return this.akna;
        }

        // zaszlo beallitasa igaz/hamis-ra
        public void SetZaszlo(bool x)
        {
            this.zaszlo = x;
            if (this.zaszlo)
            {
                this.Image = Properties.Resources.zaszlo;
            }
            else
            {
                this.Image = null;
            }
        }

        // meg van-e jelolve a hely zaszloval
        public bool GetZaszlo()
        {
            return this.zaszlo;
        }

        // a hely felfedese - beallitasa igaz/hamis-ra
        public void SetFelfedve(bool x)
        {
            this.felfedve = x;
            if (this.felfedve)
            {
                this.BackColor = Color.White;
                if (this.akna)
                {
                    if (Hely.vege)
                    {
                        this.Image = Properties.Resources.bomba;
                    } else
                    {
                        this.Image = Properties.Resources.felrobbant_bomba;
                    }
                } else
                {
                    if (Hely.vege && this.zaszlo)
                    { 
                        this.Image = Properties.Resources.nincs_bomba;
                    } else
                    {
                        this.Image = null;
                        if (this.AknakMellette > 0)
                        {
                            this.Text = this.AknakMellette.ToString();
                        }
                    }
                }
            }
            else
            {
                this.BackColor = Color.LightGray;
            }            
        }

        // fel van-e fedve a hely
        public bool GetFelfedve()
        {
            return this.felfedve;
        }

    }
}
