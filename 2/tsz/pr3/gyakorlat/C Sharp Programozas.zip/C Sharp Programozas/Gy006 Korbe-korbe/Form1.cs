﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gy006_Korbe_korbe
{
    public partial class Form1 : Form
    {

        private int szamlalo = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            szamlalo++;
            switch (szamlalo)
            {
                case 1:
                    button1.Location = new Point(this.ClientSize.Width - button1.Size.Width,0);
                    break;
                case 2:
                    button1.Location = new Point(this.ClientSize.Width - button1.Size.Width, this.ClientSize.Height - button1.Size.Height);
                    break;
                case 3:
                    button1.Location = new Point(0, this.ClientSize.Height - button1.Size.Height);
                    break;
                case 4:
                    button1.Location = new Point(0, 0);
                    szamlalo = 0;
                    break;
            }

        }
    }
}
