﻿using System;
using System.Windows.Forms;

namespace _006_Lokalis_es_globalis_valtozok
{
    public partial class Form1 : Form
    {

        // a = globalis valtozo
        private int a = 0;

        public Form1()
        {
            InitializeComponent();
        }


        private void hozzaad(int x)
        {
            // x, y = lokalis valtozok
            int y = 2 * x;
            a = a + y;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            hozzaad(5);
            label1.Text = "Az \"a\" változó értéke: " + a;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Az \"a\" változó értéke: " + a;
        }

    }
}
