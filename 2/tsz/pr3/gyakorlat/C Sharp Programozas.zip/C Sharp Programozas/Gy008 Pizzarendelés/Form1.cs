﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gy007_Pizzarendelés
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            double ar = 2.5;
            if (checkBox1.Checked)
            {
                ar += 0.8;
            }
            if (checkBox2.Checked)
            {
                ar += 0.7;
            }
            if (checkBox3.Checked)
            {
                ar += 0.75;
            }
            if (checkBox4.Checked)
            {
                ar += 0.6;
            }
            if (checkBox5.Checked)
            {
                ar += 0.45;
            }
            string strAr = ar.ToString("N2");         
            label2.Text = "Pizza ára: " + strAr + " EUR";
        }
    }
}
