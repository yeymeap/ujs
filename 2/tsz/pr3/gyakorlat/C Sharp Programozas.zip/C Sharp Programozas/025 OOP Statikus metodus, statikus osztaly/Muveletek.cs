﻿using System.Windows.Forms;

namespace _025_OOP_Statikus_metodus__statikus_osztaly
{
    public static class Muveletek
    {
        public static int Osszeadas(int a, int b)
        {
            return a + b;
        }

        public static int Kivonas(int a, int b)
        {
            return a - b;
        }

        public static int Szorzas(int a, int b)
        {
            return a * b;
        }

        public static double Osztas(int a, int b)
        {
            return (double)a / b;
        }

    }
}
