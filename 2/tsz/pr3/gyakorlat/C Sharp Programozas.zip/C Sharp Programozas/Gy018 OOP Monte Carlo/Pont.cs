﻿using System;

namespace Gy018_OOP_Monte_Carlo
{
    public class Pont
    {
        private static Random rgen = new Random();

        private double x, y;

        public Pont(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public Pont(double xMin, double xMax, double yMin, double yMax)
        {
            x = rgen.NextDouble() * (xMax - xMin) + xMin;
            y = rgen.NextDouble() * (yMax - yMin) + yMin;
        }

        public double GetX()
        {
            return x;
        }

        public double GetY()
        {
            return y;
        }

        public override string ToString()
        {
            return "(" + x + "," + y + ")";
        }

        public double TavolsagOrigotol()
        {
            return Math.Sqrt(Math.Pow(x, 2) + Math.Pow(y, 2));
        }

    }
}
