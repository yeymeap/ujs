﻿using System;

namespace Gy018_OOP_Monte_Carlo
{
    public class Kor
    {
        private double x, y, sugar;

        public Kor(double x, double y, double sugar)
        {
            this.x = x;
            this.y = y;
            this.sugar = sugar;
        }

        public string KolcsonosHelyzet(Kor k)
        {
            double t = Math.Sqrt(Math.Pow(x - k.x, 2) + Math.Pow(y - k.y, 2));
            if (sugar + k.sugar < t)
            {
                return "A két körnek nincs közös pontja.";
            } else if (sugar + k.sugar == t)
            {
                return "A két kör kívülről érinti egymást.";
            } else if (Math.Abs(sugar - k.sugar) == t)
            {
                return "A két kör belülről érinti egymást.";
            } else if (Math.Abs(sugar - k.sugar) > t)
            {
                return "Az egyik kör a másik belsejében van.";
            } else
            {
                return "A két kör metszi egymást.";
            }
        }

        public override string ToString()
        {
            return "(" + x + "," + y + "," + sugar + ")";
        }

        public bool ElemeAKornek(Pont p)
        {
            return Math.Sqrt(Math.Pow(x - p.GetX(), 2) + Math.Pow(y - p.GetY(), 2)) <= sugar;
        }

    }
}
