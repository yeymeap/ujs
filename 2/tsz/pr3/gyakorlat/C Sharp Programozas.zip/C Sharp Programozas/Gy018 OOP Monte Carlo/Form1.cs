﻿using System;
using System.Windows.Forms;

namespace Gy018_OOP_Monte_Carlo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBox1.Text);
            int osszPontokSzama = Convert.ToInt32(textBox2.Text);
            Kor k = new Kor(n / 2.0, n / 2.0, n / 2.0);
            int korbeEsoPontokSzama = 0;
            for (int i = 0; i < osszPontokSzama; i++)
            {
                Pont p = new Pont(0, n, 0, n);
                if (k.ElemeAKornek(p))
                {
                    korbeEsoPontokSzama++;
                }
            }
            textBox3.Clear();
            textBox3.AppendText("Körbe eső pontok száma: " + korbeEsoPontokSzama + "\r\n");
            textBox3.AppendText("4 * " + korbeEsoPontokSzama + " / " + osszPontokSzama + " = " +
                                4 * korbeEsoPontokSzama / (double)osszPontokSzama);
        }
    }
}
