﻿using System;
using System.Windows.Forms;

namespace _030_Timer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int szamlalo = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {
            szamlalo++;
            label1.Text = szamlalo.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }
    }
}
