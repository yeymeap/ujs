﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _038_Interface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Repules(TextBox tbox, IRepulniTudo valami)
        {
            tbox.AppendText(valami.Repul() + "\r\n");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Helikopter h = new Helikopter(2011);
            Bagoly b = new Bagoly(2015);
            Repules(textBox1, h);
            Repules(textBox1, b);
        }
    }
}
