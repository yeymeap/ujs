﻿namespace _038_Interface
{
    public interface IRepulniTudo
    {
        string Repul(); 
    }
}