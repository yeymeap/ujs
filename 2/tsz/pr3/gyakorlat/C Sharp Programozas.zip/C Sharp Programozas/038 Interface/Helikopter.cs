﻿namespace _038_Interface
{
    public class Helikopter : Jarmu, IRepulniTudo
    {
        public Helikopter(int gyartasiEv) : base(gyartasiEv)
        {
        }

        public string Repul()
        {
            return "A helikopter repül a város felett.";
        }
    }
}
