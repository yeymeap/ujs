﻿namespace _038_Interface
{
    public class Allat
    {
        private int szuletesiEv;

        public Allat(int szuletesiEv)
        {
            this.szuletesiEv = szuletesiEv;
        }

        public string Taplalkozik()
        {
            return this.GetType().Name + " taplalkozik.";
        }

    }
}
