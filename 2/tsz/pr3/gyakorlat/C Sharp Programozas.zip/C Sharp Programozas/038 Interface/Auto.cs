﻿namespace _038_Interface
{
    public class Auto : Jarmu
    {
        public const int KEREKEKSZAMA = 4;

        public Auto(int gyartasiEv) : base(gyartasiEv)
        {
        }
    }
}
