﻿namespace _038_Interface
{
    public class Kutya : Allat
    {
        public Kutya(int szuletesiEv) : base(szuletesiEv)
        {
        }

        public string Ugat()
        {
            return "A kutya ugat.";
        }
    }
}
