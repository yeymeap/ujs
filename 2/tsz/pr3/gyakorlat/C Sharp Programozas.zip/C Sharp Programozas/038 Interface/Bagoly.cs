﻿namespace _038_Interface
{
    public class Bagoly : Allat, IRepulniTudo
    {
        public Bagoly(int szuletesiEv) : base(szuletesiEv)
        {
        }

        public string Repul()
        {
            return "A bagoly repül az erdő felett.";
        }
    }
}
