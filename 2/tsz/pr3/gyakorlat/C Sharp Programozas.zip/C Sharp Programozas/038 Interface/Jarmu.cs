﻿namespace _038_Interface
{
    public class Jarmu
    {
        private int gyartasiEv;

        public Jarmu(int gyartasiEv)
        {
            this.gyartasiEv = gyartasiEv;
        }

        public string Indul()
        {
            return this.GetType().Name + " indul.";
        }

        public string Leall()
        {
            return this.GetType().Name + " leáll.";
        }

    }
}
