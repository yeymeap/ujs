﻿using System;

namespace Gy022_Mertani_testek
{
    public class Henger : MertaniTest
    {
        private double sugar, magassag;

        public Henger(double sugar, double magassag)
        {
            this.sugar = sugar;
            this.magassag = magassag;
        }

        public override double Terfogat()
        {
            return Math.Pow(sugar, 2) * Math.PI * magassag;
        }
    }
}
