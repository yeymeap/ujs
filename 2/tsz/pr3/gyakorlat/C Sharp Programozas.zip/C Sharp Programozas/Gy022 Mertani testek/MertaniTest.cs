﻿using System;

namespace Gy022_Mertani_testek
{
    public abstract class MertaniTest : IComparable
    {
        public abstract double Terfogat();

        public override string ToString()
        {
            return GetType().Name + " terfogata: " + Terfogat();
        }

        public int CompareTo(object obj)
        {
            MertaniTest m = (MertaniTest)obj;
            if (this.Terfogat() > m.Terfogat())
            {
                return 1;
            }
            else if (this.Terfogat() < m.Terfogat())
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }
    }
}
