﻿namespace Gy022_Mertani_testek
{
    public class Teglatest : MertaniTest
    {
        private double a, b, c;

        public Teglatest(double a, double b, double c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public override double Terfogat()
        {
            return a * b * c;
        }
    }
}
