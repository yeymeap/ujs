﻿using System;
using System.Windows.Forms;

namespace _008_OOP_1
{
    public partial class Form1 : Form
    {
        Szemely sz1;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sz1 = new Szemely();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (sz1 != null)
            {
                sz1.SetNev("Peti");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (sz1 != null)
            {
                label1.Text = sz1.GetNev();
            }
        }
    }

    class Szemely
    {
        private string _nev;
        
        public Szemely()
        {
            _nev = "Ismeretlen";
        }

        public string GetNev()
        {
            return _nev;
        }

        public void SetNev(string nev)
        {
            _nev = nev;
        }

    }

}
