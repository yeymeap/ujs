﻿namespace Gy014_OOP_Fenykepalbum
{
    class NagyFenykepalbum : Fenykepalbum
    {
        public NagyFenykepalbum() : base(64)
        {
        }
    }
}
