﻿namespace Gy014_OOP_Fenykepalbum
{

    class Fenykepalbum
    {
        private int _lapokSzama;

        public Fenykepalbum()
        {
            _lapokSzama = 16;
        }

        public Fenykepalbum(int lapokSzama)
        {
            _lapokSzama = lapokSzama;
        }

        public int GetLapokSzama()
        {
            return _lapokSzama;
        }

    }
}
