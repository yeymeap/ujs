﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gy014_OOP_Fenykepalbum
{
    public partial class Form1 : Form
    {

        private Fenykepalbum f1, f2;
        private NagyFenykepalbum f3;

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (f1!=null && f2!=null && f3!=null)
            {
                textBox1.AppendText("--- Albumok oldalszámai ---\n");
                textBox1.AppendText("Első album " + f1.GetLapokSzama() + " oldalas.\n");
                textBox1.AppendText("Második album " + f2.GetLapokSzama() + " oldalas.\n");
                textBox1.AppendText("Harmadik album " + f3.GetLapokSzama() + " oldalas.\n");
            }
            else
            {
                MessageBox.Show("Előbb létre kell hozni a fényképalbumokat!", "Hiba!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.AppendText("--- Albumok létrehozása ---\n");
            f1 = new Fenykepalbum();
            f2 = new Fenykepalbum(24);
            f3 = new NagyFenykepalbum();
        }
    }
}
