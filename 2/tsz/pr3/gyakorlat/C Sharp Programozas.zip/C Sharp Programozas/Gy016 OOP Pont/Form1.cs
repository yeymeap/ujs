﻿using System;
using System.Windows.Forms;

namespace Gy016_OOP_Pont
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // pontok letrehozasa
            Pont[] a = new Pont[20];
            for(int i=0; i<a.Length; i++)
            {
                a[i] = new Pont(-100, 100, -50, 50);            
            }
            // pontok kiirasa es atlagtavolsag szamitasa, legtavolabbi pont
            textBox1.Clear();
            double osszeg = 0;
            Pont legtavolabbi = a[0];
            for (int i = 0; i < a.Length; i++)
            {             
                textBox1.AppendText(a[i] + " távolsága origótól: " + a[i].TavolsagOrigotol() + "\r\n");
                // osszegszamitas
                osszeg += a[i].TavolsagOrigotol();
                // legtavolabbi pont keresese
                if (a[i].TavolsagOrigotol() > legtavolabbi.TavolsagOrigotol())
                {
                    legtavolabbi = a[i];
                }
            }
            textBox1.AppendText("Átlagtávolság: " + osszeg / a.Length + "\r\n");
            textBox1.AppendText("Legtávolabbi pont: " + legtavolabbi + " távolsága origótól: " + 
                                legtavolabbi.TavolsagOrigotol() + "\r\n");


        }
    }
}
