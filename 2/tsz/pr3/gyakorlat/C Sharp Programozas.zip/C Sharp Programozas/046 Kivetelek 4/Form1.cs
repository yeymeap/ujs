﻿using System;
using System.Windows.Forms;

namespace _046_Kivetelek_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nev = textBox1.Text;
            string szulSzam = textBox2.Text;            
            try
            {
                Szemely sz = new Szemely(nev, szulSzam);
                textBox3.AppendText(sz + "\r\n");
            }
            catch (HibasNevException exc1)
            {
                MessageBox.Show(exc1.Message, "HIBA",
                  MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (HibasSzuletesiSzamException exc2)
            {
                MessageBox.Show(exc2.Message, "HIBA",
                  MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
