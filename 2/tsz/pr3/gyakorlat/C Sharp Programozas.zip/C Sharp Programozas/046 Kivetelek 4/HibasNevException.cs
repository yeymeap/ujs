﻿using System;

namespace _046_Kivetelek_4
{
    public class HibasNevException : Exception
    {
        public HibasNevException() : base("Hibás név!")
        {            
        }

        public HibasNevException(string hibauzenet) : base(hibauzenet)
        {
        }

    }
}
