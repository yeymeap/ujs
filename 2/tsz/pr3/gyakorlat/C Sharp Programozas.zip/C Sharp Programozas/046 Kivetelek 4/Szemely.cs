﻿using System;

namespace _046_Kivetelek_4
{
    public class Szemely
    {
        private string nev;
        private string szulSzam;

        public Szemely(string nev, string szulSzam)
        {
            // nev ellenorzese
            if (nev.Length<3)
            {
                throw new HibasNevException("A névnek legalább 3 betűből kell állnia!");
            }
            // szuletesi szam ellenorzese
            long sz = 0;
            try
            {
                sz = Convert.ToInt64(szulSzam);
            }
            catch (FormatException) when (szulSzam.Length == 0)
            {
                throw new HibasSzuletesiSzamException("Nincs megadva a születési szám!");               
            }
            catch (FormatException)
            {
                throw new HibasSzuletesiSzamException("A születési szám csak számjegyeket tartalmazhat!");
            }
            if (sz % 11 != 0)
            {
                throw new HibasSzuletesiSzamException();
            }
            // ha ideaig eljutottunk, akkor minden OK
            this.nev = nev;
            this.szulSzam = szulSzam;
        }

        public override string ToString()
        {
            return nev + " (" + szulSzam + ")";
        }

    }
}
