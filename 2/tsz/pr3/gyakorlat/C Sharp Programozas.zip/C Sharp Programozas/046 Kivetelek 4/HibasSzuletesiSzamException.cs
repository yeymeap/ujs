﻿using System;

namespace _046_Kivetelek_4
{
    public class HibasSzuletesiSzamException : Exception
    {
        public HibasSzuletesiSzamException() : base("Hibás születési szám!")
        {
        }

        public HibasSzuletesiSzamException(string hibauzenet) : base(hibauzenet)
        {
        }

    }
}
