﻿using System;

namespace _023_OOP_Absztrakt_osztaly_es_metodus
{
    public abstract class Alakzat
    {
        protected int szelesseg, magassag;

        public Alakzat(int szelesseg, int magassag)
        {
            this.szelesseg = szelesseg;
            this.magassag = magassag;
        }

        public string Info()
        {
            string s = GetType().Name + " objektum - ";
            s += "szelessege: " + szelesseg + ", ";
            s += "magassaga: " + magassag + ", ";
            s += "terulete: " + Math.Round(Terulet(), 2);
            return s;
        }

        public abstract double Terulet();

    }
}
