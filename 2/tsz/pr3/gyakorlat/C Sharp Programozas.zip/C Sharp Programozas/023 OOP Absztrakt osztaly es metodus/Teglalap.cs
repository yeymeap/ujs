﻿namespace _023_OOP_Absztrakt_osztaly_es_metodus
{
    public class Teglalap : Alakzat
    {
        public Teglalap(int szelesseg, int magassag) : base(szelesseg, magassag)
        {
        }

        public override double Terulet()
        {
            return szelesseg * magassag;
        }
    }
}
