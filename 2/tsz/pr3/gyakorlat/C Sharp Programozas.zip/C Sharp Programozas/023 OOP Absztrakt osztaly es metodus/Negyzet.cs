﻿namespace _023_OOP_Absztrakt_osztaly_es_metodus
{
    public class Negyzet : Teglalap
    {
        public Negyzet(int szelesseg) : base(szelesseg, szelesseg)
        {
        }
    }
}
