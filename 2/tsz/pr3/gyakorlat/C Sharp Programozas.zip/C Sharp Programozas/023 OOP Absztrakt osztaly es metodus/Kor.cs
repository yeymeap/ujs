﻿namespace _023_OOP_Absztrakt_osztaly_es_metodus
{
    public class Kor : Ellipszis
    {
        public Kor(int szelesseg) : base(szelesseg, szelesseg)
        {
        }
    }
}
