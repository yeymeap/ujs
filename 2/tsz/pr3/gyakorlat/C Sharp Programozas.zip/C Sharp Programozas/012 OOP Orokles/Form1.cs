﻿using System;
using System.Windows.Forms;

namespace _012_OOP_Orokles
{
    public partial class Form1 : Form
    {

        Diak d1, d2;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] d1jegyei = { 1, 2, 2, 1, 2 };
            d1 = new Diak("Feri", 2003, d1jegyei);
            int[] d2jegyei = { 1, 1, 3, 1 };
            d2 = new Diak("Timi", 2002, d2jegyei);
            textBox1.AppendText("d1, d2 objektumok létrehozva\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.AppendText(d1.Nev + " születési éve: " + d1.SzuletesiEv
                + ", életkora: " + d1.Eletkor() + "\n");
            textBox1.AppendText(d2.Nev + " születési éve: " + d2.SzuletesiEv
                + ", életkora: " + d2.Eletkor() + "\n");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.AppendText(d1.Nev + " jegyei: ");
            foreach(int j in d1.OsszesJegy())
            {
                textBox1.AppendText(j + ", ");
            }
            textBox1.AppendText("\n");
            textBox1.AppendText(d2.Nev + " jegyei: ");
            foreach (int j in d2.OsszesJegy())
            {
                textBox1.AppendText(j + ", ");
            }
            textBox1.AppendText("\n");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int j = Convert.ToInt32(textBox2.Text);
            d1.UjJegy(j);
            textBox1.AppendText(d1.Nev + " kapott egy jegyet: " + j + "\n");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int j = Convert.ToInt32(textBox3.Text);
            d2.UjJegy(j);
            textBox1.AppendText(d2.Nev + " kapott egy jegyet: " + j + "\n");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.AppendText(d1.Nev + " jegyeinek atlaga: " + d1.Atlag() + "\n");
            textBox1.AppendText(d2.Nev + " jegyeinek atlaga: " + d2.Atlag() + "\n");
        }

    }
}
