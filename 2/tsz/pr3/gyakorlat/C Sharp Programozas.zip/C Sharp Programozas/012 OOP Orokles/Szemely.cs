﻿using System;

namespace _012_OOP_Orokles
{
    public class Szemely
    {
        public string Nev { get; }
        public int SzuletesiEv { get; }

        public Szemely(string aNev, int aSzuletesiEv)
        {
            Nev = aNev;
            SzuletesiEv = aSzuletesiEv;
        }

        public int Eletkor()
        {
            return DateTime.Now.Year - SzuletesiEv;
        }
    }
}

