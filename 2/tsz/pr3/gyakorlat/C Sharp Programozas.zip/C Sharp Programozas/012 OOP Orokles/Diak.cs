﻿using System;

namespace _012_OOP_Orokles
{
    public class Diak : Szemely
    {
        private int[] _jegyek = new int[50];
        private int _jegyekSzama = 0;

        public Diak(string aNev, int aSzuletesiEv, int[] aJegyek) : base(aNev, aSzuletesiEv)
        {
            for (int i = 0; i < aJegyek.Length; i++)
            {
                _jegyek[i] = aJegyek[i];
            }
            _jegyekSzama = aJegyek.Length;
        }

        public int[] OsszesJegy()
        {
            int[] a = new int[_jegyekSzama];
            for (int i=0; i<_jegyekSzama; i++)
            {
                a[i] = _jegyek[i];
            }
            return a;
        }

        public void UjJegy(int aJegy)
        {
            _jegyek[_jegyekSzama] = aJegy;
            _jegyekSzama++;
        }

        public double Atlag()
        {
            double atlag = 0;
            for(int i=0; i<_jegyekSzama; i++)
            {
                atlag = atlag + _jegyek[i];
            }
            atlag = Math.Round(atlag / _jegyekSzama, 2);
            return atlag;
        }

    }
}


