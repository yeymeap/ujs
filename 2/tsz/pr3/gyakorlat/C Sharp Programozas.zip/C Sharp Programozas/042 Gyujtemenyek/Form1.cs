﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace _042_Gyujtemenyek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<int> szamok = new List<int>();
            szamok.Add(28);
            szamok.Add(39);
            szamok.Add(17);
            szamok.Add(65);
            textBox1.Clear();
            for (int i = 0; i < szamok.Count; i++)
            {
                textBox1.AppendText(szamok[i] + ", ");
            }
            textBox1.AppendText("\r\n\r\n");
            textBox1.AppendText("Legkisebb elem: " + szamok.Min() + "\r\n");
            textBox1.AppendText("Legnagyobb elem: " + szamok.Max() + "\r\n");
            textBox1.AppendText("Számok összege: " + szamok.Sum() + "\r\n");
            textBox1.AppendText("Számok átlaga: " + szamok.Average() + "\r\n\r\n");
            szamok.Sort();
            textBox1.AppendText("Rendezve: ");
            foreach (int szam in szamok)
            {
                textBox1.AppendText(szam + ", ");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LinkedList<int> szamok = new LinkedList<int>();
            szamok.AddLast(28);
            szamok.AddLast(39);
            szamok.AddLast(17);
            szamok.AddLast(65);
            textBox1.Clear();
            foreach (int szam in szamok)
            {
                textBox1.AppendText(szam + ", ");
            }
            textBox1.AppendText("\r\n\r\n");
            textBox1.AppendText("Legkisebb elem: " + szamok.Min() + "\r\n");
            textBox1.AppendText("Legnagyobb elem: " + szamok.Max() + "\r\n");
            textBox1.AppendText("Számok összege: " + szamok.Sum() + "\r\n");
            textBox1.AppendText("Számok átlaga: " + szamok.Average() + "\r\n\r\n");
            textBox1.AppendText("Kiírás referencia használatával:\r\n");
            LinkedListNode<int> akt = szamok.First;
            while (akt != null)
            {
                textBox1.AppendText(akt.Value + ", ");
                akt = akt.Next;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Dictionary<string, string> telefonkonyv = new Dictionary<string, string>();
            telefonkonyv.Add("0903/222-333", "Peti");
            telefonkonyv.Add("0905/555-777", "Zoli");
            telefonkonyv.Add("0903/018-018", "Kati");
            telefonkonyv.Add("0908/802-802", "Timi");
            textBox1.Clear();
            foreach (string tszam in telefonkonyv.Keys)
            {
                textBox1.AppendText(tszam + " : " + telefonkonyv[tszam] + "\r\n");
            }
            textBox1.AppendText("\r\n");
            telefonkonyv.Remove("0905/555-777");
            textBox1.AppendText("A 0905/555-777 szám törlése után:\r\n");
            foreach (string tszam in telefonkonyv.Keys)
            {
                textBox1.AppendText(tszam + " : " + telefonkonyv[tszam] + "\r\n");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SortedList<string, string> telefonkonyv = new SortedList<string, string>();
            telefonkonyv.Add("0903/222-333", "Peti");
            telefonkonyv.Add("0905/555-777", "Zoli");
            telefonkonyv.Add("0903/018-018", "Kati");
            telefonkonyv.Add("0908/802-802", "Timi");
            textBox1.Clear();
            foreach (string tszam in telefonkonyv.Keys)
            {
                textBox1.AppendText(tszam + " : " + telefonkonyv[tszam] + "\r\n");
            }
            textBox1.AppendText("\r\n");
            telefonkonyv.Remove("0905/555-777");
            textBox1.AppendText("A 0905/555-777 szám törlése után:\r\n");
            foreach (string tszam in telefonkonyv.Keys)
            {
                textBox1.AppendText(tszam + " : " + telefonkonyv[tszam] + "\r\n");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            HashSet<int> szamok = new HashSet<int>();
            szamok.Add(59);
            szamok.Add(23);
            szamok.Add(40);
            szamok.Add(18);
            szamok.Add(77);
            szamok.Add(40);
            szamok.Add(40);
            textBox1.Clear();
            foreach (int szam in szamok)
            {
                textBox1.AppendText(szam + ", ");
            }
            textBox1.AppendText("\r\n\r\n");
            textBox1.AppendText("Legkisebb elem: " + szamok.Min() + "\r\n");
            textBox1.AppendText("Legnagyobb elem: " + szamok.Max() + "\r\n");
            textBox1.AppendText("Számok összege: " + szamok.Sum() + "\r\n");
            textBox1.AppendText("Számok átlaga: " + szamok.Average() + "\r\n\r\n");
            int[] a = { 8, 40, 17, 23, 55 };
            szamok.UnionWith(a);
            textBox1.AppendText("Unió a { 8, 40, 17, 23, 55 } tömbbel:\r\n");
            foreach (int szam in szamok)
            {
                textBox1.AppendText(szam + ", ");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SortedSet<int> szamok = new SortedSet<int>();
            szamok.Add(59);
            szamok.Add(23);
            szamok.Add(40);
            szamok.Add(18);
            szamok.Add(77);
            szamok.Add(40);
            szamok.Add(40);
            textBox1.Clear();
            foreach (int szam in szamok)
            {
                textBox1.AppendText(szam + ", ");
            }
            textBox1.AppendText("\r\n\r\n");
            textBox1.AppendText("Legkisebb elem: " + szamok.Min() + "\r\n");
            textBox1.AppendText("Legnagyobb elem: " + szamok.Max() + "\r\n");
            textBox1.AppendText("Számok összege: " + szamok.Sum() + "\r\n");
            textBox1.AppendText("Számok átlaga: " + szamok.Average() + "\r\n\r\n");
            int[] a = { 8, 40, 17, 23, 55 };
            szamok.UnionWith(a);
            textBox1.AppendText("Unió a { 8, 40, 17, 23, 55 } tömbbel:\r\n");
            foreach (int szam in szamok)
            {
                textBox1.AppendText(szam + ", ");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Queue<string> nevek = new Queue<string>();
            nevek.Enqueue("Balázs");
            nevek.Enqueue("Katalin");
            nevek.Enqueue("Aladár");
            nevek.Enqueue("Erzsébet");
            nevek.Enqueue("Zoltán");
            textBox1.Clear();
            textBox1.AppendText("Első elem: " + nevek.Peek() + "\r\n");
            textBox1.AppendText("Elemek darabszáma: " + nevek.Count + "\r\n\r\n");
            textBox1.AppendText("Elemek a sorban:\r\n");
            foreach (string s in nevek)
            {
                textBox1.AppendText(s + "\r\n");
            }
            textBox1.AppendText("\r\n");
            textBox1.AppendText("Elemek kiszedése: \r\n");
            while (nevek.Count > 0)
            {
                textBox1.AppendText(nevek.Dequeue() + "\r\n");
            }
            textBox1.AppendText("\r\n");
            textBox1.AppendText("Elemek darabszáma: " + nevek.Count);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Stack<string> nevek = new Stack<string>();
            nevek.Push("Balázs");
            nevek.Push("Katalin");
            nevek.Push("Aladár");
            nevek.Push("Erzsébet");
            nevek.Push("Zoltán");
            textBox1.Clear();
            textBox1.AppendText("Legfelső elem: " + nevek.Peek() + "\r\n");
            textBox1.AppendText("Elemek darabszáma: " + nevek.Count + "\r\n\r\n");
            textBox1.AppendText("Elemek a veremben:\r\n");
            foreach (string s in nevek)
            {
                textBox1.AppendText(s + "\r\n");
            }
            textBox1.AppendText("\r\n");
            textBox1.AppendText("Elemek kiszedése: \r\n");
            while (nevek.Count > 0)
            {
                textBox1.AppendText(nevek.Pop() + "\r\n");
            }
            textBox1.AppendText("\r\n");
            textBox1.AppendText("Elemek darabszáma: " + nevek.Count);
        }

    }
}
