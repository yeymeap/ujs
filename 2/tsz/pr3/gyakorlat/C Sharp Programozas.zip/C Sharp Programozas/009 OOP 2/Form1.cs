﻿using System;
using System.Windows.Forms;

namespace _009_OOP_2
{
    public partial class Form1 : Form
    {
        Szemely sz1;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sz1 = new Szemely();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (sz1 != null)
            {
                sz1.Nev = "Peti";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (sz1 != null)
            {
                label1.Text = sz1.Nev;
            }
        }
    }

    class Szemely
    {
        private string _nev;

        public string Nev
        {
            get { return _nev; }
            set { _nev = value; }
        }
        
        public Szemely()
        {
            _nev = "Ismeretlen";
        }

    }

}
