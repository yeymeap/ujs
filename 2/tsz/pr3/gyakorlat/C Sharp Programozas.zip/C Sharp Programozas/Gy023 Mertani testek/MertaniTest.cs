﻿using System;
using System.Collections;

namespace Gy023_Mertani_testek
{
    public abstract class MertaniTest : IComparable
    {
        public abstract double Terfogat();
        public abstract double Felszin();

        public override string ToString()
        {
            return GetType().Name + " térfogata: " + Terfogat() + ", felszíne: " + Felszin();
        }

        public int CompareTo(object obj)
        {
            MertaniTest m = (MertaniTest)obj;
            if (this.Terfogat() > m.Terfogat())
            {
                return 1;
            }
            else if (this.Terfogat() < m.Terfogat())
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }

        private class FelszinKomparer : IComparer
        {
            public int Compare(object x, object y)
            {
                MertaniTest m1 = (MertaniTest)x;
                MertaniTest m2 = (MertaniTest)y;
                if (m1.Felszin() > m2.Felszin())
                {
                    return 1;
                }
                else if (m1.Felszin() < m2.Felszin())
                {
                    return -1;
                }
                else
                {
                    return 0;
                }
            }
        }

        public static IComparer FelszinSzerintiRendezes()
        {
            return new FelszinKomparer();
        }
    }
}
