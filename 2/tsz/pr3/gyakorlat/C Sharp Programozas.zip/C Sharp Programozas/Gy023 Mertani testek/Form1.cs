﻿using System;
using System.Windows.Forms;

namespace Gy023_Mertani_testek
{
    public partial class Form1 : Form
    {

        private MertaniTest[] testek = new MertaniTest[10];
        private Random rnd = new Random();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for(int i=0; i<testek.Length; i++)
            {
                switch(rnd.Next(3))
                {
                    case 0:
                        testek[i] = new Teglatest(rnd.Next(1, 10), rnd.Next(1, 10), rnd.Next(1, 10));
                        break;
                    case 1:
                        testek[i] = new Gomb(rnd.Next(1, 10));
                        break;
                    case 2:
                        testek[i] = new Henger(rnd.Next(1, 10), rnd.Next(1, 10));
                        break;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Array.Sort(testek);
            textBox1.Clear();
            for(int i=0; i<testek.Length; i++)
            {
                textBox1.AppendText(testek[i] + "\r\n");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Array.Sort(testek, MertaniTest.FelszinSzerintiRendezes());
            textBox1.Clear();
            for (int i = 0; i < testek.Length; i++)
            {
                textBox1.AppendText(testek[i] + "\r\n");
            }
        }
    }
}
