﻿using System;

namespace Gy023_Mertani_testek
{
    public class Gomb : MertaniTest
    {
        private double sugar;

        public Gomb(double sugar)
        {
            this.sugar = sugar;
        }

        public override double Terfogat()
        {
            return 4 * Math.Pow(sugar, 3) * Math.PI / 3;
        }

        public override double Felszin()
        {
            return 4 * Math.Pow(sugar, 2) * Math.PI;
        }
    }
}
