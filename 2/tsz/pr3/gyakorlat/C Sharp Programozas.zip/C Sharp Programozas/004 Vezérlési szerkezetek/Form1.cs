﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _004_Vezérlési_szerkezetek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = 7, b = 8, c = 12;

            if ((a == 7 && b == 8) || c == 10)
            {
                textBox1.AppendText(String.Format("a={0}, b={1}, c={2}\n", a, b, c));
            } else
            {
                textBox1.AppendText("A feltetel nem igaz!\n");
            }

            switch (a)
            {
                case 5:
                    textBox1.AppendText("öt\n");
                    break;
                case 7:
                    textBox1.AppendText("hét\n");
                    break;
                default:
                    textBox1.AppendText("egyik sem\n");
                    break;
            }

            for (int i = 0; i < 10; i++)
            {
                textBox1.AppendText(i + ", ");
            }
            textBox1.AppendText("\n");

            while (a>=0)
            {
                textBox1.AppendText(a + ", ");
                a--;
            }
            textBox1.AppendText("\n");

            do
            {
                textBox1.AppendText(b + ", ");
                b--;
            } while (b > 0);
            textBox1.AppendText("\n");

            int[] tomb = { 70, 18, 45, 33, 25, 77 };
            foreach (int x in tomb)
            {
                textBox1.AppendText(x + ", ");
            }
            textBox1.AppendText("\n");

        }
    }
}
