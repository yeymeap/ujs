﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gy011_Csuszkas_szamologep
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void hScrollBar1_ValueChanged(object sender, EventArgs e)
        {
            label1.Text = "Első szám: " + hScrollBar1.Value;
        }

        private void hScrollBar2_ValueChanged(object sender, EventArgs e)
        {
            label2.Text = "Második szám: " + hScrollBar2.Value;
            if (hScrollBar2.Value == 0)
            {
                button4.Enabled = false;
            } else
            {
                button4.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label3.Text = "Eredmény: " + (hScrollBar1.Value + hScrollBar2.Value);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label3.Text = "Eredmény: " + (hScrollBar1.Value - hScrollBar2.Value);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label3.Text = "Eredmény: " + (hScrollBar1.Value * hScrollBar2.Value);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label3.Text = "Eredmény: " + ((double)hScrollBar1.Value / hScrollBar2.Value);
        }
    }
}
