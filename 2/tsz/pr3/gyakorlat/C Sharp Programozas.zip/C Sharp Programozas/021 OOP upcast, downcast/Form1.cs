﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _021_OOP_Upcast__downcast
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Diak d = new Diak("Feri", 2003, new int[] { 1, 2, 2, 1, 2 });
            textBox1.AppendText("----- d objektum: -----\n");
            textBox1.AppendText("Nev: " + d.Nev + "\n");
            textBox1.AppendText("Eletkor: " + d.Eletkor() + "\n");
            textBox1.AppendText("Jegyek atlaga: " + d.Atlag() + "\n");

            // --- UPCAST --- ősre konvertálás
            Szemely sz = d;
            textBox1.AppendText("----- sz objektum: -----\n");
            textBox1.AppendText("Nev: " + sz.Nev + "\n");
            textBox1.AppendText("Eletkor: " + sz.Eletkor() + "\n");
            // textBox1.AppendText("Jegyek atlaga: " + sz.Atlag() + "\n");

            // --- DOWNCAST --- gyermekre konvertalas
            Diak d2 = (Diak)sz;
            textBox1.AppendText("----- d2 objektum: -----\n");
            textBox1.AppendText("Nev: " + d2.Nev + "\n");
            textBox1.AppendText("Eletkor: " + d2.Eletkor() + "\n");
            textBox1.AppendText("Jegyek atlaga: " + d2.Atlag() + "\n");

        }
    }
}
