﻿using System;
using System.Windows.Forms;

namespace _040_IEnumerable__IEnumerator
{
    public partial class Form1 : Form
    {
        Verem v = new Verem(10);

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            v.ElemBe(textBox1.Text);
            textBox1.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = v.ElemKi();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            foreach(string s in v)
            {
                textBox2.AppendText(s + "\r\n");
            }
        }
    }
}
