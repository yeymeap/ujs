﻿using System;
using System.Collections;

namespace _040_IEnumerable__IEnumerator
{
    public class Verem : IEnumerable
    {
        private string[] elemek;
        private int n = 0;

        public Verem(int meret)
        {
            elemek = new string[meret];
        }

        public void ElemBe(string s)
        {
            if (n < elemek.Length)
            {
                elemek[n] = s;
                n++;
            }
        }

        public string ElemKi()
        {
            if (n > 0)
            {
                n--;
                return elemek[n];                
            }
            return null;
        }

        public IEnumerator GetEnumerator()
        {
            string[] tomb = new string[n];
            Array.Copy(elemek, 0, tomb, 0, n);
            return new VeremEnumerator(tomb);
        }        
    }
}
