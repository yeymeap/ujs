﻿using System.Collections;

namespace _040_IEnumerable__IEnumerator
{
    public class VeremEnumerator : IEnumerator
    {
        private string[] tomb;
        private int index;

        public object Current
        {
            get
            {
                return tomb[index];
            }
        }

        public VeremEnumerator(string[] tomb)
        {
            this.tomb = tomb;
            index = tomb.Length;
        }

        public bool MoveNext()
        {
            index--;
            return index >= 0;
        }

        public void Reset()
        {
            index = tomb.Length;
        }
    }
}
