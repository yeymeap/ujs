﻿using System;
using System.Windows.Forms;

namespace _028_Eroforrasok_hasznalata
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int zaszloSzamlalo = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            zaszloSzamlalo++;
            switch (zaszloSzamlalo)
            {
                case 1:
                    button1.Image = Properties.Resources.zaszlo;
                    break;
                case 2:
                    button1.Image = null;
                    zaszloSzamlalo = 0;
                    break;
            }
        }

        private int bombaSzamlalo = 0;

        private void button2_Click(object sender, EventArgs e)
        {
            bombaSzamlalo++;
            switch (bombaSzamlalo)
            {
                case 1:
                    button2.Image = Properties.Resources.bomba;
                    break;
                case 2:
                    button2.Image = Properties.Resources.nincs_bomba;
                    break;
                case 3:
                    button2.Image = Properties.Resources.felrobbant_bomba;
                    break;
                case 4:
                    button2.Image = null;
                    bombaSzamlalo = 0;
                    break;
            }
        }
    }
}
