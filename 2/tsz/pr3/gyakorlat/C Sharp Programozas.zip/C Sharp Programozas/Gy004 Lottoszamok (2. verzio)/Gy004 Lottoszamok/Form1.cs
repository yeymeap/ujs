﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gy004_Lottoszamok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] a = new int[5];
            Random randgen = new Random();
            // szamok generalasa
            for (int i=0; i<5; i++)
            {
                int r;
                do
                {
                    r = randgen.Next(1, 91);                  
                } while (Array.IndexOf(a,r)>=0);
                a[i] = r;                
            }
            // szamok rendezese
            Array.Sort(a);
            // szamok kiirasa
            label1.Text = "Számok: ";
            foreach (int x in a)
            {
                label1.Text += x + ", ";
            }
        }
    }
}
