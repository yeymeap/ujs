﻿namespace _036_Struktura
{
    public class PontOsztaly
    {
        public int X { set; get; }
        public int Y { set; get; }

        public PontOsztaly(int x, int y)
        {
            X = x;
            Y = y;
        }

        public override string ToString()
        {
            return "(" + X + "," + Y + ")";
        }
    }
}
