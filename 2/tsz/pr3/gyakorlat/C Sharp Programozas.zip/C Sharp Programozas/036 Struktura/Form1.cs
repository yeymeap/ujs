﻿using System;
using System.Windows.Forms;

namespace _036_Struktura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            PontStruktura a = new PontStruktura(10, 15);
            PontStruktura b = a;            
            textBox1.AppendText("A pont: " + a.ToString() + "\r\n");            
            textBox1.AppendText("B pont: " + b.ToString() + "\r\n");
            b.X = 8;
            b.Y = 23;
            textBox1.AppendText("A pont: " + a.ToString() + "\r\n");
            textBox1.AppendText("B pont: " + b.ToString() + "\r\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            PontOsztaly a = new PontOsztaly(10, 15);
            PontOsztaly b = a;
            textBox1.AppendText("A pont: " + a.ToString() + "\r\n");
            textBox1.AppendText("B pont: " + b.ToString() + "\r\n");
            b.X = 8;
            b.Y = 23;
            textBox1.AppendText("A pont: " + a.ToString() + "\r\n");
            textBox1.AppendText("B pont: " + b.ToString() + "\r\n");
        }
    }
}
