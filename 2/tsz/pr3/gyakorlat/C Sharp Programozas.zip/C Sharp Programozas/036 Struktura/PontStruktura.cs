﻿namespace _036_Struktura
{
    public struct PontStruktura
    {
        public int X { set; get; }
        public int Y { set; get; }

        public PontStruktura(int x, int y)
        {
            X = x;
            Y = y;
        }

        public override string ToString()
        {
            return "(" + X + "," + Y + ")";
        }
    }
}
