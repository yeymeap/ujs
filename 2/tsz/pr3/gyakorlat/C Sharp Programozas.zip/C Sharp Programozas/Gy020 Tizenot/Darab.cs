﻿using System.Drawing;
using System.Windows.Forms;

namespace Gy020_Tizenot
{
    public class Darab : Button
    {

        public const int MERET = 100;        // egy jatekdarab (nyomogomb) merete

        private static int szamlalo = 0;

        public Darab()
        {
            Darab.szamlalo++;
            this.Text = Darab.szamlalo.ToString();
            this.Size = new Size(Darab.MERET, Darab.MERET);
            this.Font = new Font("Arial", Darab.MERET / 3);
            this.SetStyle(ControlStyles.Selectable, false);
        }

        public void Csere(Darab d)
        {
            string szoveg = this.Text;
            this.Text = d.Text;
            d.Text = szoveg;
            bool lathatosag = this.Visible;
            this.Visible = d.Visible;
            d.Visible = lathatosag;
        }

        public int GetOszlop()
        {
            return this.Location.X / Darab.MERET;
        }

        public int GetSor()
        {
            return this.Location.Y / Darab.MERET;
        }

    }
}
