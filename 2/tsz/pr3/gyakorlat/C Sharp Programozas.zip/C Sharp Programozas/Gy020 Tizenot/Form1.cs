﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Gy020_Tizenot
{
    public partial class Form1 : Form
    {
        private Darab[,] darabok = new Darab[4, 4]; // 16 jatekdarab
        private int x = 3, y = 3; // a lathatatlan darab oszlopa es sora

        private Random rgen = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // jatekdarabok letrehozasa
            for (int sor = 0; sor < 4; sor++)
            {
                for (int oszlop = 0; oszlop < 4; oszlop++)
                {
                    darabok[sor, oszlop] = new Darab();
                    darabok[sor, oszlop].Location = new Point(oszlop * Darab.MERET, sor * Darab.MERET);
                    darabok[sor, oszlop].Click += new EventHandler(EgerKattintas);
                    this.Controls.Add(darabok[sor, oszlop]);
                }
            }
            // tizenhatodik darab lathatatlanna tetele
            darabok[3, 3].Visible = false;
            // ablak atmeretezese
            this.ClientSize = new Size(4 * Darab.MERET, 4 * Darab.MERET);
            // jatekdarabok megkeverese
            DarabokKeverese();
        }

        private void EgerKattintas(Object sender, EventArgs e)
        {
            Darab d = (Darab)sender;
            int dx = d.GetOszlop();
            int dy = d.GetSor();
            Console.WriteLine(dx + " " + dy);
            Console.WriteLine(x + " " + y);
            if (Math.Abs(x - dx) + Math.Abs(y - dy) == 1)
            {
                darabok[y, x].Csere(d);
                x = dx;
                y = dy;
            }
            if (Kirakva())
            {
                MessageBox.Show("Sikerült kirani!", "Gratulálunk!");
                DarabokKeverese();
            }
        }

        private void DarabokKeverese()
        {
            int[] xd = { 0, 0, -1, +1 };
            int[] yd = { -1, +1, 0, 0 };
            int i = 0;
            do
            {
                int j = rgen.Next(4);
                if (x + xd[j] >= 0 && x + xd[j] < 4 && y + yd[j] >= 0 && y + yd[j] < 4)
                {
                    darabok[y, x].Csere(darabok[y + yd[j], x + xd[j]]);
                    x = x + xd[j];
                    y = y + yd[j];
                    i++;
                }
            } while (i < 100);
        }

        private bool Kirakva()
        {
            int k = 1;
            for (int sor = 0; sor < 4; sor++)
            {
                for (int oszlop = 0; oszlop < 4; oszlop++)
                {
                    if (darabok[sor, oszlop].Text == k.ToString())
                    {
                        k++;
                    }
                }
            }
            return k==17;
        }
    }
}
