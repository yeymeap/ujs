﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _014_OOP_Feladat___Munkas
{
    public partial class Form1 : Form
    {
        Munkas m1, m2;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            m1 = new Munkas("Zoli", 1995, 590);
            m2 = new Munkas("Tomi", 1997, 560);
            textBox1.AppendText("m1, m2 objektumok létrehozva\n");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.AppendText(m1.Nev + " születési éve: " + m1.SzuletesiEv
                + ", életkora: " + m1.Eletkor() + ", fizetése: " + m1.GetFizetes() + " EUR\n");
            textBox1.AppendText(m2.Nev + " születési éve: " + m2.SzuletesiEv
                + ", életkora: " + m2.Eletkor() + ", fizetése: " + m2.GetFizetes() + " EUR\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sz = Convert.ToInt32(textBox2.Text);
            m1.FizetesEmeles(sz);
            textBox1.AppendText(m1.Nev + " fizetése " + sz + " %-kal növekedett\n");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int sz = Convert.ToInt32(textBox3.Text);
            m1.FizetesCsokkentes(sz);
            textBox1.AppendText(m1.Nev + " fizetése " + sz + " %-kal csökkent\n");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int sz = Convert.ToInt32(textBox4.Text);
            m2.FizetesEmeles(sz);
            textBox1.AppendText(m2.Nev + " fizetése " + sz + " %-kal növekedett\n");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int sz = Convert.ToInt32(textBox5.Text);
            m2.FizetesCsokkentes(sz);
            textBox1.AppendText(m2.Nev + " fizetése " + sz + " %-kal csökkent\n");
        }

    }
}
