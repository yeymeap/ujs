﻿using System;

namespace _014_OOP_Feladat___Munkas
{
    public class Munkas : Szemely
    {

        private double _fizetes;

        public Munkas(string aNev, int aSzuletesiEv, double aFizetes) : base(aNev, aSzuletesiEv)
        {
            _fizetes = aFizetes;
        }

        public double GetFizetes()
        {
            return _fizetes;
        }

        public void FizetesEmeles(int szazalek)
        {
            _fizetes = _fizetes + _fizetes * (szazalek / 100.0);
            _fizetes = Math.Round(_fizetes, 2);
        }

        public void FizetesCsokkentes(int szazalek)
        {
            _fizetes = _fizetes - _fizetes * (szazalek / 100.0);
            _fizetes = Math.Round(_fizetes, 2);
        }

    }
}
