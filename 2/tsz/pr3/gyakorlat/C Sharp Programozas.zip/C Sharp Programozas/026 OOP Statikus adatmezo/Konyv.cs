﻿namespace _026_OOP_Statikus_adatmezo
{
    public class Konyv
    {        
        private string szerzo;
        private string cim;
        private int id;

        private static int szamlalo = 0;

        public Konyv(string szerzo, string cim)
        {
            this.szerzo = szerzo;
            this.cim = cim;
            id = szamlalo;
            szamlalo++;
        }

        public override string ToString()
        {
            return id + " : " + szerzo + " : " + cim;
        }

    }
}
