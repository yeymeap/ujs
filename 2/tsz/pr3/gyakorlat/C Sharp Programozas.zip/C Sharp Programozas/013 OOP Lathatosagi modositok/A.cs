﻿using System.Windows.Forms;

namespace _013_OOP_Lathatosagi_modositok
{
    public class A
    {
        public int x = 1;
        private int y = 2;
        protected int z = 3;

        public void KiirasA(TextBox tbox)
        {
            tbox.AppendText("x = " + x + ", ");
            tbox.AppendText("y = " + y + ", ");
            tbox.AppendText("z = " + z + "\n");
        }

    }
}

