﻿using System.Windows.Forms;

namespace _013_OOP_Lathatosagi_modositok
{
    public class B : A
    {
        public void KiirasB(TextBox tbox)
        {
            tbox.AppendText("x = " + x + ", ");
            tbox.AppendText("y nem látható, ");
            tbox.AppendText("z = " + z + "\n");
        }
    }
}

