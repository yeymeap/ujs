﻿using System;
using System.Windows.Forms;

namespace _013_OOP_Lathatosagi_modositok
{
    public partial class Form1 : Form
    {
        private A a = new A();
        private B b = new B();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            a.KiirasA(textBox1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            b.KiirasB(textBox1);
        }

        private void KiirasForm1(TextBox tbox)
        {
            tbox.AppendText("a.x = " + a.x + ", ");
            tbox.AppendText("a.y nem látható, ");
            tbox.AppendText("a.z nem látható\n");
            tbox.AppendText("b.x = " + b.x + ", ");
            tbox.AppendText("b.y nem látható, ");
            tbox.AppendText("b.z nem látható\n");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            KiirasForm1(textBox1);
        }
    }
}
