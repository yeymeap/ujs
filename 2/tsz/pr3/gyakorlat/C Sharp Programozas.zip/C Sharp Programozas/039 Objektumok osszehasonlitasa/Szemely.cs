﻿using System;
using System.Collections;

namespace _039_Objektumok_osszehasonlitasa
{
    public class Szemely : IComparable
    {
        private string nev;
        private int szulEv;
        private int magassag;

        public Szemely(string nev, int szulEv, int magassag)
        {
            this.nev = nev;
            this.szulEv = szulEv;
            this.magassag = magassag;
        }

        public override string ToString()
        {
            return nev + " (" + szulEv + ") magassaga: " + magassag + " cm";
        }

        // az objektumokat alapertelmezetten nev szerint hasonlitjuk ossze
        public int CompareTo(object obj)
        {
            Szemely sz = (Szemely)obj;
            return nev.CompareTo(sz.nev);
        }

        // ----- szuletesi ev szerinti osszehasonlitashoz -----
        private class SzulEvComparer : IComparer
        {
            public int Compare(object x, object y)
            {
                Szemely sz1 = (Szemely)x;
                Szemely sz2 = (Szemely)y;
                return sz1.szulEv - sz2.szulEv;
            }
        }

        public static IComparer SzulEvSzerintiRendezes()
        {
            return new SzulEvComparer();
        }
        
        // ----- magassag szerinti osszehasonlitashoz -----
        private class MagassagComparer : IComparer
        {
            public int Compare(object x, object y)
            {
                Szemely sz1 = (Szemely)x;
                Szemely sz2 = (Szemely)y;
                return sz1.magassag - sz2.magassag;
            }
        }

        public static IComparer MagassagSzerintiRendezes()
        {
            return new MagassagComparer();
        }

    }
}
