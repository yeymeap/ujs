﻿using System;
using System.Windows.Forms;

namespace _039_Objektumok_osszehasonlitasa
{
    public partial class Form1 : Form
    {
        private Szemely[] szemelyek;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            szemelyek = new Szemely[4];
            szemelyek[0] = new Szemely("Peti", 2007, 182);
            szemelyek[1] = new Szemely("Kati", 2009, 167);
            szemelyek[2] = new Szemely("Zoli", 1998, 170);
            szemelyek[3] = new Szemely("Timi", 2001, 174);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Array.Sort(szemelyek);
            textBox1.Clear();
            foreach (Szemely x in szemelyek)
            {
                textBox1.AppendText(x + "\r\n");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Array.Sort(szemelyek, Szemely.SzulEvSzerintiRendezes());
            textBox1.Clear();
            foreach (Szemely x in szemelyek)
            {
                textBox1.AppendText(x + "\r\n");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Array.Sort(szemelyek, Szemely.MagassagSzerintiRendezes());
            textBox1.Clear();
            foreach (Szemely x in szemelyek)
            {
                textBox1.AppendText(x + "\r\n");
            }
        }
    }
}
