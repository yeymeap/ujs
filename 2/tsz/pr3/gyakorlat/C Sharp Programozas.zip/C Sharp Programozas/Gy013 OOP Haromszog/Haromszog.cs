﻿using System;

namespace Gy013_OOP_Haromszog
{
    class Haromszog
    {
        private int a, b, c;

        public Haromszog(int aa, int bb, int cc)
        {
            a = aa;
            b = bb;
            c = cc;
        }

        public int GetA()
        {
            return a;
        }

        public int GetB()
        {
            return b;
        }

        public int GetC()
        {
            return c;
        }

        public bool Egyenloszaru()
        {
            return a == b || a == c || b == c;
        }

        public bool Szabalyos()
        {
            return a == b && b == c;
        }

        public int Kerulet()
        {
            return a + b + c;
        }

        public double Terulet()
        {
            double s = Kerulet() / 2.0;
            return Math.Sqrt(s*(s-a)*(s-b)*(s-c));
        }

    }
}
