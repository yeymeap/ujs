﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gy013_OOP_Haromszog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Haromszog h = new Haromszog(Convert.ToInt32(textBox1.Text),
                                        Convert.ToInt32(textBox2.Text),
                                        Convert.ToInt32(textBox3.Text));
            textBox4.Clear();
            textBox4.AppendText("a=" + h.GetA() + ", b=" + h.GetB() + ", c=" + h.GetC() + "\n");
            if (h.Egyenloszaru()) {
                textBox4.AppendText("A háromszög egyenlőszárú.\n");
            } else
            {
                textBox4.AppendText("A háromszög NEM egyenlőszárú.\n");
            }
            if (h.Szabalyos())
            {
                textBox4.AppendText("A háromszög szabályos.\n");
            }
            else
            {
                textBox4.AppendText("A háromszög NEM szabályos.\n");
            }
            textBox4.AppendText("A háromszög kerülete: " + h.Kerulet() + "\n");
            textBox4.AppendText("A háromszög területe: " + h.Terulet() + "\n");
        }
    }
}
