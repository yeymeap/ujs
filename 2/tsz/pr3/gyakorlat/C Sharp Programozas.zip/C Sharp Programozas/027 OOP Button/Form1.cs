﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace _027_OOP_Button
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // uj nyomogomb letrehozasa
            Button b = new Button();
            // a gomb tulajsondagainak beallitasa
            b.Text = "Katt ide!";
            b.Location = new Point(50, 50);
            b.Size = new Size(80, 30);
            // a fuggveny hozzarendelese a 'MouseDown' esemenyhez
            b.MouseDown += new MouseEventHandler(MouseDownEvent);
            // a gomb hozaadasa a Form-hoz
            this.Controls.Add(b);
        }

        private void MouseDownEvent(Object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                MessageBox.Show("A gombon JOBB egérgomb kattintás történt!",
                    "Kattintás");
            }
            if (e.Button == MouseButtons.Left)
            {
                MessageBox.Show("A gombon BAL egérgomb kattintás történt!",
                    "Kattintás");
            }
        }

    }
}
