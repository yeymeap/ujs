﻿using System;

namespace Gy017_OOP_Kor
{
    public class Kor
    {
        private double x, y, sugar;

        public Kor(double x, double y, double sugar)
        {
            this.x = x;
            this.y = y;
            this.sugar = sugar;
        }

        public string KolcsonosHelyzet(Kor k)
        {
            double t = Math.Sqrt(Math.Pow(x - k.x, 2) + Math.Pow(y - k.y, 2));
            if (sugar + k.sugar < t)
            {
                return "A két körnek nincs közös pontja.";
            } else if (sugar + k.sugar == t)
            {
                return "A két kör kívülről érinti egymást.";
            } else if (Math.Abs(sugar - k.sugar) == t)
            {
                return "A két kör belülről érinti egymást.";
            } else if (Math.Abs(sugar - k.sugar) > t)
            {
                return "Az egyik kör a másik belsejében van.";
            } else
            {
                return "A két kör metszi egymást.";
            }
        }

        public override string ToString()
        {
            return "(" + x + "," + y + "," + sugar + ")";
        }

    }
}
