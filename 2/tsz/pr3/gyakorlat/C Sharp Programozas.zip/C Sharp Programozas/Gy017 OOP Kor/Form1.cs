﻿using System;
using System.Windows.Forms;

namespace Gy017_OOP_Kor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Kor x = new Kor(5, 5, 5);
            Random rgen = new Random();
            for (int i=0; i<20; i++)
            {
                Kor y = new Kor(rgen.Next(0, 21), rgen.Next(0, 21), rgen.Next(0, 21));
                textBox1.AppendText("x"+ x + " és y" + y + ": ");
                textBox1.AppendText(x.KolcsonosHelyzet(y) + "\r\n");
            }
        }
    }
}
