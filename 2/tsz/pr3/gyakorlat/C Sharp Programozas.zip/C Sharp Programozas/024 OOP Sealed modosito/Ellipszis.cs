﻿using System;

namespace _024_OOP_Sealed_modosito
{
    public class Ellipszis : Alakzat
    {
        public Ellipszis(int szelesseg, int magassag) : base(szelesseg, magassag)
        {
        }

        public override double Terulet()
        {
            return (szelesseg / 2.0) * (magassag / 2.0) * Math.PI;
        }
    }
}
