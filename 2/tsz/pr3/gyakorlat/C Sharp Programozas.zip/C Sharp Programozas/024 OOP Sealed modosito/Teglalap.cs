﻿namespace _024_OOP_Sealed_modosito
{
    public class Teglalap : Alakzat
    {
        public Teglalap(int szelesseg, int magassag) : base(szelesseg, magassag)
        {
        }

        public override double Terulet()
        {
            return szelesseg * magassag;
        }
    }
}
