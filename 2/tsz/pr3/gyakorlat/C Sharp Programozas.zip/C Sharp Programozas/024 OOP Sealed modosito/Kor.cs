﻿namespace _024_OOP_Sealed_modosito
{
    public sealed class Kor : Ellipszis
    {
        public Kor(int szelesseg) : base(szelesseg, szelesseg)
        {
        }
    }
}
