﻿namespace _024_OOP_Sealed_modosito
{
    public sealed class Negyzet : Teglalap
    {
        public Negyzet(int szelesseg) : base(szelesseg, szelesseg)
        {
        }
    }
}
