﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _024_OOP_Sealed_modosito
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Alakzat[] al = new Alakzat[4];

        private void Form1_Load(object sender, EventArgs e)
        {
            al[0] = new Teglalap(5, 3);
            al[1] = new Negyzet(5);
            al[2] = new Ellipszis(5, 3);
            al[3] = new Kor(5);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            for (int i = 0; i < al.Length; i++)
            {
                textBox1.AppendText(al[i].Info() + "\n");
            }
        }
    }
}
