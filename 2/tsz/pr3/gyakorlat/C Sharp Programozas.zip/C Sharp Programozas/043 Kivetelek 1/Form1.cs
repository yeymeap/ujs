﻿using System;
using System.Windows.Forms;

namespace _043_Kivetelek_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sz1 = Convert.ToInt32(textBox1.Text);
            int sz2 = Convert.ToInt32(textBox2.Text);
            int osszeg = sz1 + sz2;
            label3.Text = "Eredmény: " + osszeg;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int sz1 = Convert.ToInt32(textBox1.Text);
                int sz2 = Convert.ToInt32(textBox2.Text);
                int osszeg = sz1 + sz2;
                label3.Text = "Eredmény: " + osszeg;
            }
            catch (FormatException exc)
            {
                MessageBox.Show("Nincs megadva két egész szám!\n(" + exc.Message + ")",
                    "HIBA", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
