﻿using System;
using System.Windows.Forms;

namespace _011_OOP_4
{
    public partial class Form1 : Form
    {
        Szemely sz1, sz2, sz3;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sz1 = new Szemely("Peti", 1996);
            sz2 = new Szemely("Éva", 1999);
            sz3 = new Szemely("Orsi", 2001);
            textBox1.AppendText("Az sz1, sz2, sz3 objektumok létrejöttek.\n");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.AppendText(sz1.Nev + " születési éve: " + sz1.SzuletesiEv 
                + ", most " + sz1.Eletkor() + " éves.\n");
            textBox1.AppendText(sz2.Nev + " születési éve: " + sz2.SzuletesiEv 
                + ", most " + sz2.Eletkor() + " éves.\n");
            textBox1.AppendText(sz3.Nev + " születési éve: " + sz3.SzuletesiEv 
                + ", most " + sz3.Eletkor() + " éves.\n");
        }

    }
}

