﻿using System;
using System.Windows.Forms;

namespace _022_OOP_This_kulcsszo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Alakzat al = new Alakzat(15, 7);
            textBox1.AppendText(al.Info() + "\n");
        }
    }
}
