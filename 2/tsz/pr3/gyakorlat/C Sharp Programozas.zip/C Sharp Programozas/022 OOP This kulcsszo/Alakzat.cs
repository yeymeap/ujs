﻿namespace _022_OOP_This_kulcsszo
{
    public class Alakzat
    {
        private int szelesseg, magassag;

        public Alakzat(int szelesseg, int magassag)
        {
            this.szelesseg = szelesseg;
            this.magassag = magassag;
        }

        public string Info()
        {
            string s = "Alakzat objektum - ";
            s += "szelessege: " + szelesseg + ", ";
            s += "magassaga: " + magassag + ", ";
            return s;
        }

    }
}
