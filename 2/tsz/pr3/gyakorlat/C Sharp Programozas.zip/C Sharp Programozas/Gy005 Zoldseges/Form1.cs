﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gy005_Zoldseges
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double ar1 = Convert.ToDouble(textBox1.Text);
            double ar2 = Convert.ToDouble(textBox2.Text);
            double ar3 = Convert.ToDouble(textBox3.Text);
            double osszes = ar1 * 1.2 + ar2 * 0.99 + ar3 * 0.75;
            osszes = Math.Round(osszes, 2);
            label4.Text = "Fizetendő: " + osszes + " EUR";
        }
    }
}
