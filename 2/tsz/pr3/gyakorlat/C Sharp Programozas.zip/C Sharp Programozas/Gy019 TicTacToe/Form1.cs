﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Gy019_TicTacToe
{
    public partial class Form1 : Form
    {
        private Button[,] jatektabla = new Button[3, 3];   // jatektabla
        private const int MERET = 100;  // nyomogombok merete
        private string jel = "X";  // melyik jatekos van soron
        private int lepesekSzama = 0;  // lepesek szama (ha =9, akkor tele a tabla)

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // negyzetek letrehozasa
            for (int sor = 0; sor < 3; sor++)
            {
                for (int oszlop = 0; oszlop < 3; oszlop++)
                {
                    jatektabla[sor, oszlop] = new Button();
                    jatektabla[sor, oszlop].Location = new Point(oszlop * MERET, sor * MERET);
                    jatektabla[sor, oszlop].Size = new Size(MERET, MERET);
                    jatektabla[sor, oszlop].Font = new Font("Arial", MERET / 2);
                    jatektabla[sor, oszlop].Click += new EventHandler(Kattintas);
                    this.Controls.Add(jatektabla[sor, oszlop]);
                }
            }
            // ablak meretenek beallitasa
            this.ClientSize = new Size(3 * MERET, 3 * MERET);
        }

        private void Kattintas(object sender, EventArgs e)
        {
            Button x = (Button)sender;
            // lepes, ha ures meg a hely
            if (x.Text == "")
            {
                x.Text = jel;
                if (jel == "X")
                {
                    jel = "O";
                }
                else
                {
                    jel = "X";
                }
                lepesekSzama++;
                // tele a tabla? >> DONTETLEN
                if (lepesekSzama == 9)
                {
                    MessageBox.Show("Döntetlen!", "Eredmény");
                    UjraInditas();
                }
                else
                {   // van az adott sorban, oszlopba, atloban harom egyforma jel?
                    int sor = x.Location.Y / MERET;
                    int oszlop = x.Location.X / MERET;
                    if (jatektabla[sor, 0].Text == jatektabla[sor, 1].Text &&
                        jatektabla[sor, 0].Text == jatektabla[sor, 2].Text)
                    {
                        MessageBox.Show(x.Text + " nyert!", "Eredmény");
                        UjraInditas();
                    }
                    else if (jatektabla[0, oszlop].Text == jatektabla[1, oszlop].Text &&
                             jatektabla[0, oszlop].Text == jatektabla[2, oszlop].Text)
                    {
                        MessageBox.Show(x.Text + " nyert!", "Eredmény");
                        UjraInditas();
                    }
                    else if (x.Text == jatektabla[0, 0].Text &&
                             x.Text == jatektabla[1, 1].Text &&
                             x.Text == jatektabla[2, 2].Text)
                    {
                        MessageBox.Show(x.Text + " nyert!", "Eredmény");
                        UjraInditas();
                    }
                    else if (x.Text == jatektabla[0, 2].Text &&
                             x.Text == jatektabla[1, 1].Text &&
                             x.Text == jatektabla[2, 0].Text)
                    {
                        MessageBox.Show(x.Text + " nyert!", "Eredmény");
                        UjraInditas();
                    }
                }
            }
        }

        private void UjraInditas()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    jatektabla[i, j].Text = "";
                }
            }
            lepesekSzama = 0;
        }

    }
}
