﻿using System;
using System.Windows.Forms;

namespace _017_OOP_ToString_metodus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Szemely[] a = new Szemely[3];

        private void Form1_Load(object sender, EventArgs e)
        {
            a[0] = new Szemely("Peti", 1996);
            a[1] = new Diak("Feri", 2003, new int[] { 1, 2, 2, 1, 2 });
            a[2] = new Munkas("Zoli", 1995, 590);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            for (int i=0; i<a.Length; i++)
            {             
                textBox1.AppendText(a[i] + "\n");
            }
        }
    }
}
