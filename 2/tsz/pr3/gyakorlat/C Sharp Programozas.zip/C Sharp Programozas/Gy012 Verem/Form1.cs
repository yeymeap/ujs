﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gy012_Verem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "")
            {
                if (listBox1.Items.Count < 10)
                {
                    listBox1.Items.Insert(0, textBox1.Text);
                    textBox1.Text = "";
                }
                else
                {
                    MessageBox.Show("A verem tele van, nem fér bele több elem!", "Tele verem");
                }
            }                        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count > 0)
            {
                textBox1.Text = listBox1.Items[0].ToString();
                listBox1.Items.RemoveAt(0);
            }
            else
            {
                MessageBox.Show("A verem üres, nincs mit kiszedni!", "Üres verem");
            }

        }
    }
}
