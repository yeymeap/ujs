﻿using System;
using System.Windows.Forms;

namespace _002_Valtozok
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*
                tobb sorbol
                allo megjegyzes
            */

            // konstans
            const double dph = 0.2;  // 20%
            
            // valtozok
            double termekAlapar = 7.85;
            double termekDPH = termekAlapar * dph;
            double termekOsszar = termekAlapar + termekDPH;

            // kiiras konzolra (Output ablakba)
            Console.WriteLine("Termek ara: " + termekAlapar);
            Console.WriteLine("20% DPH: " + termekDPH);
            Console.WriteLine("Osszesen: " + termekOsszar);

            // kiiras TextBox-ba
            textBox1.AppendText("Termek ara: " + termekAlapar + "\n");
            textBox1.AppendText("20% DPH: " + termekDPH + "\n");
            textBox1.AppendText("Osszesen: " + termekOsszar + "\n");

            // tovabbi adattipusok
            int egeszSzam = 25;
            double valosSzam = 2.8;
            char karakter = 'A';
            string karakterlanc = "Hello!";
            bool logikai = true;

            // tomb deklaralasa
            int[] tomb1 = new int[50];
            double[] tomb2 = { 3.5, 4.7, 2.8 };

            // stringre alakitas - 1. modszer
            textBox1.AppendText(Convert.ToString(egeszSzam));
            textBox1.AppendText("\n");
            // stringre alakitas - 2. modszer
            textBox1.AppendText(egeszSzam.ToString());
            textBox1.AppendText("\n");
            // stringre alakitas - 3. modszer
            textBox1.AppendText(egeszSzam + "\n");
            textBox1.AppendText(valosSzam + "\n");
            textBox1.AppendText(karakter + "\n");
            textBox1.AppendText(karakterlanc + "\n");
            textBox1.AppendText(logikai + "\n");

            // string szamma alakitasa
            string s1 = "20";
            string s2 = "8,6";
            textBox1.AppendText(s1 + s2 + "\n");    // 208.6
            textBox1.AppendText(Int32.Parse(s1) + Double.Parse(s2) + "\n");    // 28.6
            textBox1.AppendText(Convert.ToInt32(s1) + Convert.ToDouble(s2) + "\n");   // 28.6

            // szamok atalakitasa
            int egeszre1 = (int)valosSzam;              // 2.8 -> 2
            int egeszre2 = Convert.ToInt32(valosSzam);  // 2.8 -> 3
            textBox1.AppendText(egeszre1 + "\n");
            textBox1.AppendText(egeszre2 + "\n");

        }
    }
}
